package com.hcsc.vbr.batchdroolsdemo.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.BaseEntityDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RateNameDTO extends BaseEntityDTO
{
    private static final long serialVersionUID = 1L;

    private String corporateEntityCode;

    private String rateName;

    private String rateConfigTypeName;

    private List<FlatRateDTO> flatRates = new ArrayList<FlatRateDTO>();

    private List<PaymentArrangementRateDTO> paymentArrangementRates = new ArrayList<PaymentArrangementRateDTO>();

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}

package com.hcsc.vbr.batchdroolsdemo.constant;

public class DroolsValidationConstants {

	public static final String DATEONE_LESSER_DATESECOND = "Lesser";
    public static final String DATEONE_GREATER_DATESECOND = "Greater";
    public static final String DATEONE_EQUAL_DATESECOND = "Equal";
    
    public static final String  INVALID_DATE = "Invalid Date";
    public static final String  VALID_DATE = "Valid Date";
    
    public static final String  VALID_PROVIDER = "Provider is Valid";
    public static final String  INVALID_PROVIDER = "Provider is Valid";
}

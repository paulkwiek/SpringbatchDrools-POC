package com.hcsc.vbr.batchdroolsdemo.batch;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.batchdroolsdemo.service.CalculationRequestService;


@Component
public class SimpleItemProcessor implements ItemProcessor<String, String> {
	
	@Autowired
	private CalculationRequestService calculationRequestService;


	@Override
	public String process(String item) throws Exception {
		System.out.println("Inside SimpleItemProcessor " + item);


//		calculationRequestService.getSubmittedCalculationRequest();
		
		return item.toUpperCase();
	}

}

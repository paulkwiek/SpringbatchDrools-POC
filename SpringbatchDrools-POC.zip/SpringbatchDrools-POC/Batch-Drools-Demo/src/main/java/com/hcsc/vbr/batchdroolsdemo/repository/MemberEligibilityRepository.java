package com.hcsc.vbr.batchdroolsdemo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.batchdroolsdemo.domain.MemberEligibility;

@Repository
public interface MemberEligibilityRepository extends JpaRepository<MemberEligibility, Integer> {
	
	
	@Query("SELECT  memberEligibility " + "    FROM  MemberEligibility memberEligibility "
			+ "   WHERE  memberEligibility.corporateEntityCode = :corporateEntityCode "
			+ "   AND    memberEligibility.lineOfBusinessCode = :lineOfBusinessCode ")
	public List<MemberEligibility> getCalculationMembers(@Param("corporateEntityCode") String corporateEntityCode,
			@Param("lineOfBusinessCode") String lineOfBusinessCode);
	

}

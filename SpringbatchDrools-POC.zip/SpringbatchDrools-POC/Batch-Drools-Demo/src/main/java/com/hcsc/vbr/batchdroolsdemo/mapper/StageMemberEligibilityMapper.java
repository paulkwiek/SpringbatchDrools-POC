package com.hcsc.vbr.batchdroolsdemo.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.batchdroolsdemo.domain.StageMemberEligibility;
import com.hcsc.vbr.batchdroolsdemo.dto.StageMemberEligibilityDTO;

@Mapper(componentModel = "spring")
public interface StageMemberEligibilityMapper {
	StageMemberEligibilityMapper INSTANCE = Mappers.getMapper(StageMemberEligibilityMapper.class);

	/**
	 * Method: toMemberEligibilityDetailDTO
	 * 
	 * @param memberEligibilityDetail
	 * @return
	 */
	public StageMemberEligibilityDTO toStageMemberEligibilityDTO(StageMemberEligibility stageMemberEligibility);

	/**
	 * Method: toMemberEligibilityDTOs
	 * 
	 * @param memberEligibilityList
	 * @return
	 */
	public List<StageMemberEligibilityDTO> toStageMemberEligibilityDTOs(List<StageMemberEligibility> stageMemberEligibilityList);

	/**
	 * Method: toMemberEligibility
	 * 
	 * @param memberEligibilityDTO
	 * @return
	 */
	public StageMemberEligibility toStageMemberEligibility(StageMemberEligibilityDTO stageMemberEligibilityDTO);

	/**
	 * Method: toMemberEligibilityList
	 * 
	 * @param memberEligibilityDTOs
	 * @return
	 */
	public List<StageMemberEligibility> toStageMemberEligibilityList(List<StageMemberEligibilityDTO> stageMemberEligibilityDTOs);
}

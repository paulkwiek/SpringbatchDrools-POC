package com.hcsc.vbr.batchdroolsdemo.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude( JsonInclude.Include.NON_NULL )
public class PaymentArrangementDTO extends DateRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer paymentArrangementId;

    private String corporateEntityCode;

    private String paymentArrangementName;

    private String arrangementFrequencyCode;

    private String paymentArrangementTypeCode;

    private String paymentArrangementDescription;

    private Integer paymentArrangementContractId;

    private String paymentTypeCode;

    private String validationStatusCode;

    private String paymentArrangementStatusDescription;

    private List<PaymentArrangementPayeeDTO> paymentArrangementPayees = new ArrayList<PaymentArrangementPayeeDTO>();

    private List<PaymentArrangementMemberSubjectDTO> paymentArrangementMemberSubjects =
        new ArrayList<PaymentArrangementMemberSubjectDTO>();

    private List<RetroActivityRuleSetupDTO> retroRuleSetups = new ArrayList<RetroActivityRuleSetupDTO>();

    private List<PaymentArrangementHistoryDTO> paymentArrangementHistories = new ArrayList<PaymentArrangementHistoryDTO>();

    private List<PaymentArrangementRateDTO> paymentArrangementRates = new ArrayList<PaymentArrangementRateDTO>();

    private String overwriteSaveArrangement;

    private String overwriteCancelArrangement;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}

package com.hcsc.vbr.batchdroolsdemo.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.batchdroolsdemo.domain.PaymentArrangementContract;
import com.hcsc.vbr.batchdroolsdemo.dto.PaymentArrangementContractDTO;



@Mapper( componentModel = "spring" )
public interface PaymentArrangementContractMapper

{
    PaymentArrangementContractMapper INSTANCE = Mappers.getMapper( PaymentArrangementContractMapper.class );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementContractDTO toContractDTO( PaymentArrangementContract contract );

    @IterableMapping( elementTargetType = PaymentArrangementContractDTO.class, qualifiedByName = "toContractDTO" )
    public List<PaymentArrangementContractDTO> toContractDTOs( List<PaymentArrangementContract> contracts );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementContract toContract( PaymentArrangementContractDTO contractDTO );

    @IterableMapping( elementTargetType = PaymentArrangementContract.class, qualifiedByName = "toContract" )
    public List<PaymentArrangementContract> toContracts( List<PaymentArrangementContractDTO> contractDTOs );
}

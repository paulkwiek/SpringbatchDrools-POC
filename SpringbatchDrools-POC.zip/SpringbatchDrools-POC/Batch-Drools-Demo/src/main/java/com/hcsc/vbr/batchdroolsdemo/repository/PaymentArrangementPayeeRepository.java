package com.hcsc.vbr.batchdroolsdemo.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.batchdroolsdemo.domain.PaymentArrangementPayee;



@Repository
public interface PaymentArrangementPayeeRepository extends JpaRepository<PaymentArrangementPayee, Long>
{
    @Query( "SELECT r FROM PaymentArrangementPayee r WHERE r.paymentArrangementPayeeId=:arrangementPayeeId" )
    public List<PaymentArrangementPayee> findByArrangementPayeeId( @Param( "arrangementPayeeId" ) Integer arrangementPayeeId );

    @Query( "SELECT paymentArrangementPayee FROM PaymentArrangementPayee paymentArrangementPayee WHERE paymentArrangementPayee.vbrPayeeId=:vbrPayeeId" )
    public List<PaymentArrangementPayee> findByPayeeId( @Param( "vbrPayeeId" ) Integer vbrPayeeId );

    /**
     * save/update/delete/NoAction for Payment arrangement payee
     * @param paymentArrangementPayees
     */
    default void savePaymentArgmtPayee( List<PaymentArrangementPayee> paymentArrangementPayees )
    {
        for( PaymentArrangementPayee paymentArrangementPayee : paymentArrangementPayees )
        {
            switch( paymentArrangementPayee.getRowAction() )
            {
                case INSERT:
                {
                    paymentArrangementPayee.setCreateRecordTimestamp( LocalDateTime.now() );
                    save( paymentArrangementPayee );
                    break;
                }
                case UPDATE:
                {
                    save( paymentArrangementPayee );
                    break;
                }
                case DELETE:
                {
                    delete( paymentArrangementPayee );
                    break;
                }
                default:
                    break;
            }
        }

    }
    
    @Query( "SELECT r FROM PaymentArrangementPayee r WHERE r.paymentArrangement.paymentArrangementId=:paymentArrangementId" )
    public List<PaymentArrangementPayee> findByPaymentArrangementId( @Param( "paymentArrangementId" ) Integer paymentArrangementId );
}

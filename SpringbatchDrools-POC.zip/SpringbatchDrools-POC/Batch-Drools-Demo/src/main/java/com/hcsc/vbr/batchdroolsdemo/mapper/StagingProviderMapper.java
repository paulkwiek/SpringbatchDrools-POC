package com.hcsc.vbr.batchdroolsdemo.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.batchdroolsdemo.domain.StagingProvider;
import com.hcsc.vbr.batchdroolsdemo.dto.StagingProviderDTO;

@Mapper(componentModel = "spring")
public interface StagingProviderMapper {

	StagingProviderMapper INSTANCE = Mappers.getMapper(StagingProviderMapper.class);

	// @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
	// @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
	@Mapping(target = "providerIdValid", ignore = true)
	public StagingProviderDTO toStagingProviderDTO(StagingProvider stagingProvider);

	// @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
	// @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
//	@Mapping(target = "providerIdValid", ignore = true)
	public StagingProvider toStagingProvider(StagingProviderDTO stagingProviderDto);

	@IterableMapping(elementTargetType = StagingProviderDTO.class, qualifiedByName = "toStagingProviderDTO")
	public List<StagingProviderDTO> toStagingProviderDTOs(List<StagingProvider> stagingProviders);

}

package com.hcsc.vbr.batchdroolsdemo.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.hcsc.vbr.batchdroolsdemo.constant.DroolsValidationConstants;
import com.hcsc.vbr.batchdroolsdemo.dto.DateValidationDTO;

public class DateValidationUtil {

	/*
	 * public static void runDateRules(DateValidationDTO dateValidationDTO,
	 * KieSession session) { session.insert(dateValidationDTO);
	 * session.fireAllRules(); }
	 */
	public static boolean dateOneLesserOrEqualDateSecond(DateValidationDTO dateValidationDTO) {

		boolean isDateOneLesserOrEqualDateSecond = false;

		if (dateValidationDTO.getDateComparisonResult().equals(DroolsValidationConstants.DATEONE_LESSER_DATESECOND)
				|| dateValidationDTO.getDateComparisonResult()
						.equals(DroolsValidationConstants.DATEONE_EQUAL_DATESECOND)) {
			isDateOneLesserOrEqualDateSecond = true;
			System.out.println("DateOne and DateSecond are in valid range, DateOne is lesser or equal to DateSecond");
		}

		System.out.println("isDateOneLesserOrEqualDateSecond value is ::" + isDateOneLesserOrEqualDateSecond);
		return isDateOneLesserOrEqualDateSecond;
	}

	public static boolean dateOneGreaterOrEqualDateSecond(DateValidationDTO dateValidationDTO) {
		boolean isDateOneGreaterorEqualDateSecond = false;

		if (dateValidationDTO.getDateComparisonResult().equals(DroolsValidationConstants.DATEONE_GREATER_DATESECOND)
				|| dateValidationDTO.getDateComparisonResult()
						.equals(DroolsValidationConstants.DATEONE_EQUAL_DATESECOND)) {
			isDateOneGreaterorEqualDateSecond = true;

			System.out.println("DateOne and DateSecond are in valid range, DateOne is greater or equal to DateSecond");
		}

		System.out.println("isDateOneGreaterorEqualDateSecond value is ::" + isDateOneGreaterorEqualDateSecond);
		return isDateOneGreaterorEqualDateSecond;
	}

	public static Date convertDate(String date) {

		SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
		Date convertedDate = null;

		try {
			convertedDate = sdformat.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
			System.out.println("Error occured inside convertDate Method and error message is :" + e.getMessage());
		}

		return convertedDate;

	}

	public static String dateValidorInvalid(boolean isStartDateValid, boolean isEndDateValid) {

		if (isStartDateValid && isEndDateValid) {
			System.out.println("Valid Dates");
			return DroolsValidationConstants.VALID_DATE;
		} else {
			System.out.println("Invalid Dates");
			return DroolsValidationConstants.INVALID_DATE;
		}
	}

	
	public static DateValidationDTO setDatesInValidationDTOInstance(Date dateOne, Date dateSecond) {
		DateValidationDTO dateValidationDTO = new DateValidationDTO();
		dateValidationDTO.setDateOne(dateOne);
		dateValidationDTO.setDateSecond(dateSecond);
		return dateValidationDTO;
	}

}

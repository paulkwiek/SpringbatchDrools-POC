package com.hcsc.vbr.batchdroolsdemo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.batchdroolsdemo.domain.StagingProvider;

@Repository
public interface StagingProviderRepository extends JpaRepository<StagingProvider, String> {
	
	@Query( "   SELECT stagingProvider FROM  StagingProvider stagingProvider "
			+ " WHERE stagingProvider.corporateEntityCode = :corporateEntityCode "
			+ " AND stagingProvider.calculationRequestId = :calculationRequestId ")
	public StagingProvider getCalculationRunStagingProvider(
			@Param("corporateEntityCode") String corporateEntityCode,
			@Param("calculationRequestId") Integer calculationRequestId);

}

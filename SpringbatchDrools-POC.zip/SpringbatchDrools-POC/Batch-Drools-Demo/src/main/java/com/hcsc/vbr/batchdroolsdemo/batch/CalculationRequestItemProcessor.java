package com.hcsc.vbr.batchdroolsdemo.batch;

import java.util.List;

import org.kie.api.runtime.KieSession;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.batchdroolsdemo.domain.CalculationArrangements;
import com.hcsc.vbr.batchdroolsdemo.domain.CalculationRequest;
import com.hcsc.vbr.batchdroolsdemo.domain.StageMemberEligibility;
import com.hcsc.vbr.batchdroolsdemo.dto.StageMemberEligibilityDTO;
import com.hcsc.vbr.batchdroolsdemo.mapper.StageMemberEligibilityMapper;
import com.hcsc.vbr.batchdroolsdemo.repository.StageMemberEligibilityRepository;
import com.hcsc.vbr.batchdroolsdemo.service.CalculationRequestService;

@Component
public class CalculationRequestItemProcessor implements ItemProcessor<CalculationRequest, String>{

	
	@Autowired
	private CalculationRequestService calculationRequestService;
	
	@Autowired
	private StageMemberEligibilityRepository stageMemberEligibilityRepository;
	
	@Autowired
	private StageMemberEligibilityMapper stageMemberEligibilityMapper;
	
	@Autowired
	private KieSession session;
	
	@Override
	public String process(CalculationRequest item) throws Exception {
		System.out.println("inside procesor");
	
		System.out.println(item.getCalculationRunName());
		
//		
//		List<CalculationArrangements> calculationArrangementsList =	item.getCalculationArrangements();
//		
//		for (CalculationArrangements calculationArrangements : calculationArrangementsList) {
//			System.out.println("calculationArrangements: " + calculationArrangements.getCalculationArrangementPK().getPaymentArrangementId());
//		}
		
		List<StageMemberEligibility> stageMemberEligibilityList= stageMemberEligibilityRepository.findAll();
		
		List<StageMemberEligibilityDTO>  stageMemberEligibilityDTOList = stageMemberEligibilityMapper.toStageMemberEligibilityDTOs(stageMemberEligibilityList);
		
		for (StageMemberEligibilityDTO stageMemberEligibilityDTO : stageMemberEligibilityDTOList) {
			System.out.println(stageMemberEligibilityDTO.getContrId());
			System.out.println("stageMemberEligibilityDTO ProcGFlag: " + stageMemberEligibilityDTO.getProcGFlag());
		    session.insert(stageMemberEligibilityDTO);
		}
		session.fireAllRules();
		
		for (StageMemberEligibilityDTO stageMemberEligibilityDTO : stageMemberEligibilityDTOList) {
		    System.out.println("stageMemberEligibilityDTO ProcGFlag: " + stageMemberEligibilityDTO.getProcGFlag());
		}
		
		
		
//		calculationRequestService.getSubmittedCalculationRequest(item);
		
		return null;
	}

}

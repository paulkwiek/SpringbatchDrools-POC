package com.hcsc.vbr.batchdroolsdemo.dto;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewCalculationRunNameDTO implements Serializable
{

    private static final long serialVersionUID = 1L;

    private String calculationRunName;

    private String corporateEntityCode;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate processPeriodDate;

    private Integer calculationRequestId;

}

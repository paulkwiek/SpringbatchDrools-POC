package com.hcsc.vbr.batchdroolsdemo.dto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class FinancePaymentDetailDTO extends BaseEntityDTO
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer financePaymentDetailId;

    private String corporateEntityCode;

    private Integer vbrPayeeId;

    private String payToPfinId;

    private String financeTypeCode;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate processPeriodDate;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate paymentEffectiveDate;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate paymentEndDate;

    private String productTypeCode;

    private String paymentTypeCode;

    private Double paymentAmount;

    private String paymentStatusCode;

    private List<FinancePaymentFinancePaymentDetailReferenceDTO> financePaymentFinancePaymentDetailReferenceList =
        new ArrayList<FinancePaymentFinancePaymentDetailReferenceDTO>();

    private List<FinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO> financePaymentDetailApprovedCalculationMemberDetailReferenceList =
        new ArrayList<FinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO>();

}

package com.hcsc.vbr.batchdroolsdemo.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.batchdroolsdemo.domain.RateName;
import com.hcsc.vbr.batchdroolsdemo.dto.RateNameDTO;

@Mapper( componentModel = "spring" )
public interface RateNameListMapper
{

    RateNameListMapper INSTANCE = Mappers.getMapper( RateNameListMapper.class );

    @Mapping( source = "rateNameId.corporateEntityCode", target = "corporateEntityCode" )
    @Mapping( source = "rateNameId.rateName", target = "rateName" )
    @Mapping( target = "flatRates", ignore = true )
    @Mapping( target = "paymentArrangementRates", ignore = true )
    public RateNameDTO toRateNameDTO( RateName rateName );

    public List<RateNameDTO> toRateNameDTOs( List<RateName> rateNames );

}

package com.hcsc.vbr.batchdroolsdemo.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DateValidationDTO {

	public Date dateOne;
	public Date dateSecond;
	public boolean IsDateValid;
	public String dateComparisonResult;
	
}

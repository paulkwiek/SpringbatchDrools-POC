package com.hcsc.vbr.batchdroolsdemo.dto;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CalculationRequestHistoryDTO extends BaseEntityDTO
{
    /**
     * 
     */

    private static final long serialVersionUID = 1L;

    private Integer calculationRequestHistoryId;

    private String corporateEntityCode;

    private Integer calculationRequestId;

    private String calculationRequestHistoryStatusCode;

}

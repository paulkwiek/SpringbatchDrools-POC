package com.hcsc.vbr.batchdroolsdemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.batchdroolsdemo.domain.CalculationMemberDetail;

@Repository
public interface CalculationMemberDetailRepository extends JpaRepository<CalculationMemberDetail, Integer> {
	

}

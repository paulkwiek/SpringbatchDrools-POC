package com.hcsc.vbr.batchdroolsdemo.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcsc.vbr.batchdroolsdemo.constant.DroolsValidationConstants;
import com.hcsc.vbr.batchdroolsdemo.domain.CalculationArrangements;
import com.hcsc.vbr.batchdroolsdemo.domain.CalculationMemberDetail;
import com.hcsc.vbr.batchdroolsdemo.domain.CalculationRequest;
import com.hcsc.vbr.batchdroolsdemo.domain.MemberEligibility;
import com.hcsc.vbr.batchdroolsdemo.domain.PaymentArrangementPayee;
import com.hcsc.vbr.batchdroolsdemo.domain.StagingProvider;
import com.hcsc.vbr.batchdroolsdemo.dto.CalculationRequestDTO;
import com.hcsc.vbr.batchdroolsdemo.dto.DateValidationDTO;
import com.hcsc.vbr.batchdroolsdemo.dto.PaymentArrangementDTO;
import com.hcsc.vbr.batchdroolsdemo.dto.StagingProviderDTO;
import com.hcsc.vbr.batchdroolsdemo.dto.VbrPayeeDTO;
import com.hcsc.vbr.batchdroolsdemo.mapper.CalculationRequestMapper;
import com.hcsc.vbr.batchdroolsdemo.mapper.PaymentArrangementMapper;
import com.hcsc.vbr.batchdroolsdemo.mapper.StagingProviderMapper;
import com.hcsc.vbr.batchdroolsdemo.repository.CalculationArrangementsRepository;
import com.hcsc.vbr.batchdroolsdemo.repository.CalculationMemberDetailRepository;
import com.hcsc.vbr.batchdroolsdemo.repository.CalculationRequestRepository;
import com.hcsc.vbr.batchdroolsdemo.repository.MemberEligibilityRepository;
import com.hcsc.vbr.batchdroolsdemo.repository.PaymentArrangementPayeeRepository;
import com.hcsc.vbr.batchdroolsdemo.repository.StagingProviderRepository;
import com.hcsc.vbr.batchdroolsdemo.util.DateValidationUtil;
import com.hcsc.vbr.batchdroolsdemo.validations.DateValidation;

import lombok.Setter;

@Service
@Setter
public class CalculationRequestService {
	
//	@Autowired
//	private CalculationRequestRepository calculationRequestRepository;
	
	@Autowired
	private CalculationArrangementsRepository calculationArrangementsRepository;
	
	@Autowired
	private PaymentArrangementPayeeRepository paymentArrangementPayeeRepository;  
	
	@Autowired
	private PaymentArrangementMapper paymentArrangementMapper;
	
	@Autowired
	private DateValidation dateValidation;
	
	@Autowired
	private MemberEligibilityRepository memberEligibilityRepository;
	
	@Autowired
	private CalculationMemberDetailRepository calculationMemberDetailRepository;
	
	@Autowired
	private KieSession session;
	
	@Autowired
	private CalculationRequestMapper calculationRequestMapper;
	
	@Autowired
	private StagingProviderRepository stagingProviderRepository;
	
	@Autowired
	private StagingProviderMapper stagingProviderMapper;
	
	public static final String CALCULATION_REQUEST_SUBMITTED = "SUBMITTED";
	
	public void getSubmittedCalculationRequest(CalculationRequest calculationRequest) {
		
		//CALCTN_ARNG_LIST 
//		List<CalculationArrangements> calculationArrangements = calculationArrangementsRepository.findSubmittedCalculationArrangements(CALCULATION_REQUEST_SUBMITTED);
		List<CalculationArrangements> calculationArrangementsList = calculationArrangementsRepository.findCalculationArrangementsByCalculationRequest(calculationRequest.getCalculationRequestId());
		
//		List<CalculationArrangements> calculationArrangements = calculationRequest.getCalculationArrangements();
		
		for (CalculationArrangements calculationArrangements : calculationArrangementsList) {
			
			if (calculationArrangements.getCalculationArrangementPK().getPaymentArrangementId().equals(937)) {
			
			System.out.println("PMT_ARNGMT_ID: " + calculationArrangements.getCalculationArrangementPK().getPaymentArrangementId() + "  CALCTN_REQ_ID: "
					+ calculationArrangements.getCalculationArrangementPK().getCalculationRequestId());
			
			
			
			List<PaymentArrangementPayee> paymentArrangementPayeesList = paymentArrangementPayeeRepository
					.findByPaymentArrangementId(calculationArrangements
							.getCalculationArrangementPK().getPaymentArrangementId());
			
			System.out.println("paymentArrangementPayeesList.size: " + paymentArrangementPayeesList.size());
			
			
				for (PaymentArrangementPayee paymentArrangementPayee : paymentArrangementPayeesList) {
					
					VbrPayeeDTO vbrPayeeDTO = paymentArrangementMapper.toVbrPayeeDTO(paymentArrangementPayee.getVbrPayee()) ;
					PaymentArrangementDTO paymentArrangementDTO = paymentArrangementMapper.toPaymentArrangmentDTO(paymentArrangementPayee.getPaymentArrangement()); 
					
					//Payment arragment and VBR Payee validation
					System.out.println("Result of date validation: " + dateValidation.validateDate(paymentArrangementDTO, vbrPayeeDTO) );
					
					//TODO: Stage Provider Validation
					
					CalculationRequestDTO calculationRequestDTO = calculationRequestMapper.toCalculationRequestDTO(calculationRequest);
					StagingProvider stagingProvider = stagingProviderRepository.getCalculationRunStagingProvider(calculationRequest.getCorporateEntityCode(), calculationRequest.getCalculationRequestId() );
					StagingProviderDTO stagingProviderDTO = stagingProviderMapper.toStagingProviderDTO(stagingProvider);

					
					String validation = executeProviderValidation(stagingProviderDTO, calculationRequestDTO);

					System.out.println("Provider: " + stagingProviderDTO.getProviderID() + " is: " + validation);

					
					//TODO: Staging Member Validation
					
					/*
					System.out.println("paymentArrangementPayee" + " " + paymentArrangementPayee.getPaymentArrangementId() +" "+ paymentArrangementPayee.getVbrPayeeId());
				
					List<MemberEligibility> memberEligibilityList = memberEligibilityRepository.getCalculationMembers(
							calculationArrangements2.getCorporateEntityCode(),
							calculationArrangements2.getLineOfBusinessCode());
					
					createCalculationMemberDetail(memberEligibilityList, paymentArrangementPayee, calculationArrangements2.getParentCalculationRequest().getCalculationRequestId());
					*/
				}
				
			}
			
		}
		
	}
	
	public List<CalculationArrangements> getSubmittedCalculationArrangements() {

		return calculationArrangementsRepository.findSubmittedCalculationArrangements(CALCULATION_REQUEST_SUBMITTED);
	}

	public void createCalculationMemberDetail(List<MemberEligibility> memberEligibilityList,
			PaymentArrangementPayee paymentArrangementPayee, Integer calculationRequestId) {

		System.out.println("Inside createCalculationMemberDetail");

		List<CalculationMemberDetail> calculationMemberDetailList = new ArrayList<CalculationMemberDetail>();

		for (MemberEligibility memberEligibility : memberEligibilityList) {

			//TODO: delete 
			if (memberEligibility.getMemberEligibilityId() == 261466) {
				System.out.println("Inside for: " + memberEligibility.getMemberEligibilityId());
				CalculationMemberDetail calculationMemberDetail = new CalculationMemberDetail();
				calculationMemberDetail.setCorporateEntityCode(memberEligibility.getCorporateEntityCode());
				calculationMemberDetail.setMemberEligibilityId(memberEligibility.getMemberEligibilityId());
				calculationMemberDetail.setPaymentArrangementId(paymentArrangementPayee.getPaymentArrangementId());
				calculationMemberDetail
						.setPaymentArrangementPayeeId(paymentArrangementPayee.getPaymentArrangementPayeeId());
				calculationMemberDetail.setPayToPfinId(paymentArrangementPayee.getVbrPayee().getPayToPfinId());
				calculationMemberDetail.setPaymentArrangementRateId(paymentArrangementPayee.getPaymentArrangement()
						.getPaymentArrangementRates().get(0).getPaymentArrangementRateId());
				calculationMemberDetail.setRateId(paymentArrangementPayee.getPaymentArrangement()
						.getPaymentArrangementRates().get(0).getParentRateName().getFlatRates().get(0).getFlatRateId());
				calculationMemberDetail.setRateConfigurationTypeCode(paymentArrangementPayee.getPaymentArrangement()
						.getPaymentArrangementRates().get(0).getParentRateName().getRateConfigTypeName());
				calculationMemberDetail.setProcessPeriodDate(memberEligibility.getProcessPeriodDate());

				if (memberEligibility.getGenderCode().equals("F")) {
					calculationMemberDetail.setPaymentRateAmount(
							paymentArrangementPayee.getPaymentArrangement().getPaymentArrangementRates().get(0)
									.getParentRateName().getFlatRates().get(0).getFemaleFlatRateAmount());
					calculationMemberDetail.setCurrentRateAmount(
							paymentArrangementPayee.getPaymentArrangement().getPaymentArrangementRates().get(0)
									.getParentRateName().getFlatRates().get(0).getFemaleFlatRateAmount());
					calculationMemberDetail.setCalculatedNetAmount(
							paymentArrangementPayee.getPaymentArrangement().getPaymentArrangementRates().get(0)
									.getParentRateName().getFlatRates().get(0).getFemaleFlatRateAmount() - 0);
				} else {
					calculationMemberDetail.setPaymentRateAmount(
							paymentArrangementPayee.getPaymentArrangement().getPaymentArrangementRates().get(0)
									.getParentRateName().getFlatRates().get(0).getMaleFlatRateAmount());
					calculationMemberDetail.setCurrentRateAmount(
							paymentArrangementPayee.getPaymentArrangement().getPaymentArrangementRates().get(0)
									.getParentRateName().getFlatRates().get(0).getMaleFlatRateAmount());
					calculationMemberDetail.setCalculatedNetAmount(
							paymentArrangementPayee.getPaymentArrangement().getPaymentArrangementRates().get(0)
									.getParentRateName().getFlatRates().get(0).getMaleFlatRateAmount() - 0);
				}

				calculationMemberDetail
						.setPaymentEffectiveDate(memberEligibility.getProcessPeriodDate().withDayOfMonth(1));
				calculationMemberDetail.setPaymentEndDate(memberEligibility.getProcessPeriodDate()
						.withDayOfMonth(memberEligibility.getProcessPeriodDate().lengthOfMonth()));
				calculationMemberDetail.setPreviousApprovedCalculationMemberDetailId(0);
				calculationMemberDetail.setRetroActivityChangeCode("");
				calculationMemberDetail.setPreviousRateAmount(0.0);
				calculationMemberDetail
						.setPaymentTypeCode(paymentArrangementPayee.getPaymentArrangement().getPaymentTypeCode());
				calculationMemberDetail.setCreateRecordTimestamp(LocalDateTime.now());
				calculationMemberDetail.setCalculationRequestId(calculationRequestId);
				calculationMemberDetail.setUpdateUserId("u411544");
				calculationMemberDetail.setCreateUserId("u411544");
				calculationMemberDetailList.add(calculationMemberDetail);
			}
		}
		calculationMemberDetailRepository.saveAll(calculationMemberDetailList);

	}
	
	public String executeProviderValidation(StagingProviderDTO stagingProviderDto,
	           CalculationRequestDTO calRequestDto) {

	       DateValidationDTO dateValidationDTO;
	       Date dateOne;
	       Date dateSecond;

	       // Comparing PinGroupStatusEffectiveDate against ProcessPeriod start Date
	       dateOne = DateValidationUtil.convertDate(stagingProviderDto.getPinGroupStatusEffectiveDate());
	       dateSecond = DateValidationUtil.convertDate(calRequestDto.getProcessPeriodDate().toString());

	       dateValidationDTO = DateValidationUtil.setDatesInValidationDTOInstance(dateOne, dateSecond);

	       // Firing date rule for comparing start date
	       // DateValidationUtil.runDateRules(dateValidationDTO,session);
	       session.insert(dateValidationDTO);
	       session.fireAllRules();

	       boolean lesserDateResult = DateValidationUtil.dateOneLesserOrEqualDateSecond(dateValidationDTO);

	       // Comparing PinGroupStatusEndDate against ProcessPeriod end Date
	       dateOne = DateValidationUtil.convertDate(stagingProviderDto.getPinGroupStatusEndDate());
	       dateSecond = DateValidationUtil.convertDate(calRequestDto.getProcessPeriodDate()
	           .withDayOfMonth(calRequestDto.getProcessPeriodDate().lengthOfMonth()).toString());

	       dateValidationDTO = DateValidationUtil.setDatesInValidationDTOInstance(dateOne, dateSecond);

	       // Firing date rule for comparing end date
	       // DateValidationUtil.runDateRules(dateValidationDTO,session);
	       session.insert(dateValidationDTO);
	       session.fireAllRules();
	       boolean greaterDateResult = DateValidationUtil.dateOneGreaterOrEqualDateSecond(dateValidationDTO);

	       // Now returning valid or invalid result only if start and end date were valid
	       // from previous operation.
	       String pinGroupStatusResult = DateValidationUtil.dateValidorInvalid(lesserDateResult, greaterDateResult);

	       // Similarly now apply date validation on ProviderFinaceLocation object

	       // Comparing ProviderFinaceLocationEffectiveDate against ProcessPeriod start
	       // Date
	       dateOne = DateValidationUtil.convertDate(stagingProviderDto.getProviderFinaceLocationEffectiveDate());
	       dateSecond = DateValidationUtil.convertDate(calRequestDto.getProcessPeriodDate().toString());

	       dateValidationDTO = DateValidationUtil.setDatesInValidationDTOInstance(dateOne, dateSecond);

	       // Firing date rule for comparing start date
	       // DateValidationUtil.runDateRules(dateValidationDTO,session);

	       session.insert(dateValidationDTO);
	       session.fireAllRules();
	       boolean lesserDateResult2 = DateValidationUtil.dateOneLesserOrEqualDateSecond(dateValidationDTO);

	       // Comparing ProviderFinaceLocationEndDate against ProcessPeriod end Date
	       dateOne = DateValidationUtil.convertDate(stagingProviderDto.getProviderFinaceLocationEndDate());
	       dateSecond = DateValidationUtil.convertDate(calRequestDto.getProcessPeriodDate()
	           .withDayOfMonth(calRequestDto.getProcessPeriodDate().lengthOfMonth()).toString());

	       dateValidationDTO = DateValidationUtil.setDatesInValidationDTOInstance(dateOne, dateSecond);

	       // Firing date rule for comparing end date
	       // DateValidationUtil.runDateRules(dateValidationDTO,session);

	       session.insert(dateValidationDTO);
	       session.fireAllRules();
	       boolean greaterDateResult2 = DateValidationUtil.dateOneGreaterOrEqualDateSecond(dateValidationDTO);

	       String providerFinaceLocationResult = DateValidationUtil.dateValidorInvalid(lesserDateResult2,
	               greaterDateResult2);

	       if (pinGroupStatusResult.equalsIgnoreCase(DroolsValidationConstants.VALID_DATE)
	               && providerFinaceLocationResult.equalsIgnoreCase(DroolsValidationConstants.VALID_DATE)
	            /*   && stagingProviderDto.isProviderIdValid()*/) {
	           return DroolsValidationConstants.VALID_PROVIDER;
	       } else {
	           return DroolsValidationConstants.INVALID_PROVIDER;
	       }

	    }

	

}

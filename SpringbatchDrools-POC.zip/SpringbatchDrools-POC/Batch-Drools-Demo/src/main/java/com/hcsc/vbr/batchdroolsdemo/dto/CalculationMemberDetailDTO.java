package com.hcsc.vbr.batchdroolsdemo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CalculationMemberDetailDTO extends CalculationMemberDetailRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer calculationMemberDetailId;

    private Integer memberEligibilityId;

    private CalculationRequestDTO parentCalculationRequest;

    private MemberEligibilityDTO parentMemberEligibility;
}

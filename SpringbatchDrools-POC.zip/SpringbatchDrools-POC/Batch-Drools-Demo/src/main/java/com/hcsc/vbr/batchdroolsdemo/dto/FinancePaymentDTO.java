package com.hcsc.vbr.batchdroolsdemo.dto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FinancePaymentDTO extends BaseEntityDTO
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer financePaymentId;

    private String corporateEntityCode;

    private LocalDate processPeriodDate;

    private Integer vbrPayeeId;

    private String payToPfinId;

    private String productTypeCode;

    private LocalDate paymentEffectiveDate;

    private LocalDate paymentEndDate;

    private String fepIndicator;

    private String financePaymentStatusCode;

    private Double totalPaymentAmount;

    private String paymentMethodCode;

    private Integer eftCheckNumber;

    private LocalDate issueDate;

    private String eftTrackingId;

    private List<FinancePaymentFinancePaymentDetailReferenceDTO> financePaymentFinancePaymentDetailReferenceList =
        new ArrayList<FinancePaymentFinancePaymentDetailReferenceDTO>();

}

package com.hcsc.vbr.batchdroolsdemo.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "STAG_MBR_ELIG" , schema = "VBRCALC")
public class StageMemberEligibility extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "ACCT_NBR", length = 20)
	private String accountNumber;

	@Column(name = "BNFT_AGRMT_NBR", length = 20)
	private String benefitAgreementNumber;

	@Column(name = "CALCTN_REQ_ID", length = 10)
	private Integer calculationRequestId;

	@Column(name = "CAN_DT", length = 20)
	private String cancelDate;

	@Column(name = "CAP_ENT_CD", length = 20)
	private String capitationEntityCode;

	@Column(name = "CNTY_CD", length = 10)
	private String countyCode;

	@Id
	@Column(name = "CONTR_ID", length = 10)
	private String contrId;

	@Column(name = "CORP_ENT_CD", length = 10)
	private String corporateEntityCode;

	@Column(name = "CTY_NM", length = 50)
	private String cityName;

	@Column(name = "DL_CRTE_TS", length = 20)
	private String dataLakeCreateTimestamp;

	@Column(name = "DL_CRTE_USR_ID", length = 20)
	private String dataLakeCreateUserId;

	@Column(name = "DL_UPD_USR_ID", length = 20)
	private String dataLakeUpdateUserId;

	@Column(name = "DL_UPDTS", length = 20)
	private String dataLakeUpdateTimestamp;

	@Column(name = "DOB", length = 20)
	private String dateOfBirth;

	@Column(name = "EFF_DT", length = 20)
	private String effectiveDate;

	@Column(name = "FST_NM", length = 50)
	private String firstName;

	@Column(name = "FUNDG_TYP_CD", length = 10)
	private String fundingTypeCode;

	@Column(name = "GNDR_CD", length = 10)
	private String genderCode;

	@Column(name = "GRP_NBR", length = 10)
	private String groupNumber;

	@Column(name = "HCN_MBI_NBR", length = 20)
	private String hcnMbiNumber;

	@Column(name = "LOB_CD", length = 10)
	private String lineOfBusinessCode;

	@Column(name = "LST_NM", length = 50)
	private String lastName;

	@Column(name = "MBR_NBR", length = 20)
	private Integer memberNumber;

	@Column(name = "MBR_PROV_EFF_DT", length = 20)
	private String memberProviderEffectiveDate;

	@Column(name = "MBR_PROV_END_DT", length = 20)
	private String memberProviderEndDate;

	@Column(name = "MBR_PROV_NM", length = 50)
	private String memberProviderName;

	@Column(name = "MID_INIT_NM", length = 20)
	private String middleInitialName;

	@Column(name = "MKTG_PLN_ID", length = 20)
	private String marketingPlanId;

	@Column(name = "PCP_ID", length = 20)
	private String pcpId;

	@Column(name = "PMT_EFF_DT", length = 20)
	private String paymentEffectiveDate;

	@Column(name = "PMT_END_DT", length = 20)
	private String paymentEndDate;

	@Column(name = "PROC_PRD_DT", length = 20)
	private String processPeriodDate;

	@Column(name = "PROCG_FLG", length = 10)
	private String procGFlag;

	@Column(name = "PROD_TYP_CD", length = 10)
	private String productTypeCode;

	@Column(name = "SECT_NBR", length = 10)
	private String sectionNumber;

	@Column(name = "ST_CD", length = 10)
	private String stateCode;

	@Column(name = "STR_ADDR_LN_1_TXT", length = 50)
	private String streetAddressLine1Text;

	@Column(name = "STR_ADDR_LN_2_TXT", length = 50)
	private String streetAddressLine2Text;

	@Column(name = "SUB_ID", length = 20)
	private String subscriberId;

	@Column(name = "SUB_SEQ_NBR", length = 20)
	private String subscribeSequenceNumber;

	@Column(name = "ZIP_CD", length = 10)
	private String zipCode;


}

package com.hcsc.vbr.batchdroolsdemo.dto;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hcsc.vbr.common.domain.BaseEntity;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StagingProviderDTO extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
	private String providerID;

	private Integer calculationRequestId;

	private String corporateEntityCode;

	private String sourceCode;

	private String statusReasonCode;

	private String providerEffectiveStartDate;

	private String providerEndDate;

	private String recordStatusCode;

	private String medgroupTypeCode;

	private String providerCLSCode;

	private String networkCode;

	private String subnetworkCode;

	private String groupId;

	private String groupTypeCode;

	private String hmoGroupTypeCode;

	private String activationDate;

	private String autoCoverageBLD;

	private String providerLocationId;

	private String cdcAccountCode;

	private String srcLastChangeTs;

	private String lastChangeUserId;

	private String validationIndicator;

	private String overrideFirstName;

	private String overrideLastName;

	private String overrideMaidenName;

	private String overrideMiddleName;

	private String overrideSuffixName;

	private String overrideTitleName;

	private String overrideOrgName;

	private String overrideOrgSecondaryName;

	private String payToCode;

	private String facilityPlanCode;

	private String providerFinanceTypeCode;

	private String rnpsNumber;

	private String rnpsNumberSequence;

	private String billingProviderFinancialId;

	private String providerLocationTaxReasonCode;

	private String billingLocationId;

	private String providerFinanceLocClosureDate;

	private String providerFinanceLocIdNumber;

	private String issuerIdNumber;

	private String providerIdTypeCode;

	private String legacyMedicarePrimaryIndicator;

	private String providerFinanceId;

	private String providerTaxId;

	private String locationUsageTypeCode;

	private String pinGroupCAPTEffectiveDate;

	private String pinGroupCAPTEndDate;

	private String pinGroupStatusEffectiveDate;

	private String pinGroupStatusEndDate;

	private String pinGroupStatusCode;

	private String providerFinaceLocationEffectiveDate;

	private String providerFinaceLocationEndDate;

	private String providerFinaceStatusReasonCode;
	
	// Adding this extra field for drools validation purpose
	private boolean providerIdValid;
	

	@Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
	
}

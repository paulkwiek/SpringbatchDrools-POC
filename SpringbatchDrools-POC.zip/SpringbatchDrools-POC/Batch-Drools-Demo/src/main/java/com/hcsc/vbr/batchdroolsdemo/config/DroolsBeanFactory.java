package com.hcsc.vbr.batchdroolsdemo.config;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.builder.KieRepository;
import org.kie.api.builder.ReleaseId;
import org.kie.api.io.Resource;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.io.ResourceFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DroolsBeanFactory {

    private static final String BASE_RULES_PATH = "droolFiles/";

	private KieServices kieServices = KieServices.Factory.get();

	@Bean
	public KieSession getKieSession() throws IOException {
		System.out.println("session created...");
		return getKieContainer().newKieSession();

	}

	@Bean
	public KieContainer getKieContainer() throws IOException {
		System.out.println("Container created...");
		getKieRepository();
		KieBuilder kb = kieServices.newKieBuilder(getKieFileSystem());
		kb.buildAll();
		KieModule kieModule = kb.getKieModule();
		KieContainer kContainer = kieServices.newKieContainer(kieModule.getReleaseId());
		return kContainer;

	}

	private void getKieRepository() {
		final KieRepository kieRepository = kieServices.getRepository();
		kieRepository.addKieModule(new KieModule() {
			public ReleaseId getReleaseId() {
				return kieRepository.getDefaultReleaseId();
			}
		});
	}

	private KieFileSystem getKieFileSystem() throws IOException {
		KieFileSystem kieFileSystem = kieServices.newKieFileSystem();
//		kieFileSystem.write(ResourceFactory.newClassPathResource("droolFiles/offer.drl"));
		// kieFileSystem.write(ResourceFactory.newClassPathResource("ArgmtRule.drl"));
		// List<String> rules=Arrays.asList(BASE_RULES_PATH +
		// ArrangementConfigRulesConstant.ARRGMT_RULE_FOLDER +
		// "ArgmtRule.drl",BASE_RULES_PATH
		// + CalculationConfigRulesConstant.CAL_RULE_FOLDER +
		// "calculation.drl",BASE_RULES_PATH +
		// ArrangementConfigRulesConstant.ARRGMT_RULE_FOLDER +
		// "MemberEligibilityRule.drl");

		List<String> rules = Arrays.asList(BASE_RULES_PATH + "offer.drl", BASE_RULES_PATH + "dateValidation.drl",
				BASE_RULES_PATH + "calculationRun.drl", BASE_RULES_PATH + "stageMember.drl");

        for(String rule:rules){
            kieFileSystem.write(ResourceFactory.newClassPathResource(rule));
        }
		return kieFileSystem;
	}

	
}

package com.hcsc.vbr.batchdroolsdemo.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.batchdroolsdemo.domain.CalculationArrangementPK;
import com.hcsc.vbr.batchdroolsdemo.domain.CalculationArrangements;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;

@Repository
public interface CalculationArrangementsRepository extends JpaRepository<CalculationArrangements, CalculationArrangementPK>
{

    /**
     * Method: saveCalculationGroup
     * @param calculationGroupings
     */
    default void saveCalculationArrangements( List<CalculationArrangements> calculationArrangementsList )
    {
        for( CalculationArrangements calculationArrangements : calculationArrangementsList )
        {
            RowActionTypes rowAction = RowActionTypes.valueOf( calculationArrangements.getRowAction().name() );
            switch( rowAction )
            {
                case INSERT:
                {
                    calculationArrangements.setCreateRecordTimestamp( LocalDateTime.now() );
                    save( calculationArrangements );
                    break;
                }
                case UPDATE:
                {
                    save( calculationArrangements );
                    break;
                }
                case DELETE:
                {
                    delete( calculationArrangements );
                    break;
                }
                case NO_ACTION:
                {
                    //Do nothing - Record is not changed
                    break;
                }
                default:
                {
                    //TODO : Future sprint exception handling
                    throw new RuntimeException( " Invalid Row Action" );
                }
            }
        }
    }
    
    @Query("SELECT  calculationArrangements " + "    FROM  CalculationArrangements calculationArrangements "
			+ "  WHERE  calculationArrangements.parentCalculationRequest.calculationRequestStatusCode = :calculationRequestStatusCode "
    		+ "  AND calculationArrangements.validationStatusCode = 'AVA' ")
	public List<CalculationArrangements> findSubmittedCalculationArrangements(
			@Param("calculationRequestStatusCode") String calculationRequestStatusCode);
    
    @Query( "  SELECT  calculationArrangements " 
    		+ " FROM  CalculationArrangements calculationArrangements "
			+ " WHERE  calculationArrangements.parentCalculationRequest.calculationRequestId = :calculationRequestId ")
	public List<CalculationArrangements> findCalculationArrangementsByCalculationRequest(
			@Param("calculationRequestId") Integer calculationRequestId);
    
}

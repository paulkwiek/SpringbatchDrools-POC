package com.hcsc.vbr.batchdroolsdemo.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

@Component
public class SimpleItemWriter implements ItemWriter<String> {

	@Override
	public void write(List<? extends String> items) throws Exception {
		System.out.println("Inside SimpleItemWriter " );
		 for(String msg : items){
	            System.out.println("In writer: " + msg);
	        }
		
	}

}

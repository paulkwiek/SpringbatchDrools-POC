package com.hcsc.vbr.batchdroolsdemo.batch;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.stereotype.Component;

@Component
public class SimpleItemReader implements ItemReader<String> {

//	private String[] msgArray = { "Hi", "!!" };
	private String[] msgArray = { "Hi" };
	private int count = 0;

	@Override
	public String read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		System.out.println("Inside SimpleItemReader");

		if (count < msgArray.length) {
			return msgArray[count++];
		} else {
			count = 0;
		}
		return null;
	}

}

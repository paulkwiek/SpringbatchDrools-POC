package com.hcsc.vbr.batchdroolsdemo.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.batchdroolsdemo.domain.PaymentArrangementPayee;
import com.hcsc.vbr.batchdroolsdemo.dto.PaymentArrangementPayeeDTO;

@Mapper( componentModel = "spring" )
public interface PaymentArrangementPayeeMapper
{
    PaymentArrangementPayeeMapper INSTANCE = Mappers.getMapper( PaymentArrangementPayeeMapper.class );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementPayeeDTO toPaymentArrangementPayeeDTO( PaymentArrangementPayee paymentArrangementPayee );

    @IterableMapping( elementTargetType = PaymentArrangementPayeeDTO.class, qualifiedByName = "toPaymentArrangementPayeeDTO" )
    public List<PaymentArrangementPayeeDTO> toPaymentArrangementPayeeDTOs( List<PaymentArrangementPayee> paymentArrangementPayees );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementPayee toPaymentArrangementPayee( PaymentArrangementPayeeDTO paymentArrangementPayeeDTO );

    @IterableMapping( elementTargetType = PaymentArrangementPayee.class, qualifiedByName = "toPaymentArrangementPayee" )
    public List<PaymentArrangementPayee> toPaymentArrangementPayees( List<PaymentArrangementPayeeDTO> paymentArrangementPayeeDTOs );
}

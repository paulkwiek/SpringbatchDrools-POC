package com.hcsc.vbr.batchdroolsdemo.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberEligibilityDTO extends MemberEligibilityRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer memberEligibilityId;

    private List<CalculationMemberDetailDTO> calculationMemberDetailList = new ArrayList<CalculationMemberDetailDTO>();

}

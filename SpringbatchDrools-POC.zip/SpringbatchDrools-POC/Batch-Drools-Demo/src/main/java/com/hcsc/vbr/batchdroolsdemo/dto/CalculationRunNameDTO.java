package com.hcsc.vbr.batchdroolsdemo.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.BaseEntityDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CalculationRunNameDTO extends BaseEntityDTO
{

    private static final long serialVersionUID = 1L;

    private String calculationRunName;

    private String corporateEntityCode;

    private String runTypeCode;

    private String runNameStatusCode;

    private List<CalculationGroupingDTO> calculationGroupings = new ArrayList<CalculationGroupingDTO>();

    private List<CalculationRequestDTO> calculationRequests = new ArrayList<CalculationRequestDTO>();

    @Override
    public String toString()
    {
        return ReflectionToStringBuilder.toString( this,
                                                   new MultilineRecursiveToStringStyleCustom() )
                .toString();
    }

}

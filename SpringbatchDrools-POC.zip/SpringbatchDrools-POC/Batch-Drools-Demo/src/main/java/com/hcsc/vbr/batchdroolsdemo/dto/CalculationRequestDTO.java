package com.hcsc.vbr.batchdroolsdemo.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class CalculationRequestDTO extends BaseEntityDTO
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer calculationRequestId;

    private String calculationRunName;

    private String corporateEntityCode;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate processPeriodDate;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS" )
    private LocalDateTime requestSubmittedTimestamp;

    private String requestSubmittedUserId;

    private String calculationRequestStatusCode;

    private String calculationRequestStatusCodeDescription;

    private CalculationRunNameDTO parentCalculationRunName;

    List<CalculationErrorLogDTO> calculationErrorLogs = new ArrayList<CalculationErrorLogDTO>();

    List<CalculationRequestHistoryDTO> calculationHistoryStatusList = new ArrayList<CalculationRequestHistoryDTO>();

    private List<CalculationMemberDetailDTO> calculationMemberDetailList = new ArrayList<CalculationMemberDetailDTO>();

    private List<ApprovedCalculationMemberDetailDTO> approvedCalculationMemberDetailList =
        new ArrayList<ApprovedCalculationMemberDetailDTO>();

    private List<CalculationArrangementsDTO> calculationArrangementsList = new ArrayList<CalculationArrangementsDTO>();

    private List<CalculationRequestGroupingDTO> calculationRequestGroupingDTOs = new ArrayList<CalculationRequestGroupingDTO>();

    private String overwriteCompletedResult;

    private String overwriteApprovedResult;

    private String operationApproveResult;

}

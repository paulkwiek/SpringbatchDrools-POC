package com.hcsc.vbr.batchdroolsdemo.repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.batchdroolsdemo.constant.CalculationServiceConstant;
import com.hcsc.vbr.batchdroolsdemo.domain.CalculationRequest;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;

@Repository
public interface CalculationRequestRepository extends JpaRepository<CalculationRequest, Integer>
{
    static final Logger LOGGER = LoggerFactory.getLogger( CalculationRequestRepository.class );

    /**
     * This method retrieves the CalculationRequest by CalculationRunName
     * Method: findByCalculationRunName
     * @param calculationRunName
     * @return CalculationRequest
     */
    @Query( "SELECT  calculationRequest "
        + "    FROM  CalculationRequest calculationRequest"
        + "   WHERE  calculationRequest.calculationRunName=:calculationRunName" )
    public CalculationRequest findByCalculationRunName( @Param( "calculationRunName" ) String calculationRunName );

    /**
     * This method retrieves the List of CalculationRequests by CorporateEntityCode and ProcessPeriodDate
     * Method: findByCorporateEntityCodeAndProcessingMonth
     * @param corporateEntityCode
     * @param processingMonth
     * @return CalculationRequests
     */
    @Query( "SELECT  calculationRequest "
        + "    FROM  CalculationRequest calculationRequest "
        + "   WHERE  calculationRequest.corporateEntityCode = :corporateEntityCode "
        + "     AND  calculationRequest.processPeriodDate = :processPeriodDate" )
    public List<CalculationRequest> findByCorporateEntityCodeAndProcessingMonth(
            @Param( "corporateEntityCode" ) String corporateEntityCode,
            @Param( "processPeriodDate" ) LocalDate processPeriodDate );

    /**
     * This method will return the list of CalculationRequest by checking corporateEntityCode
     * processPeriodDate and status code of ('CRCS','CASU','CAIP','CAFL','CAAP' )
     * Method: findReviewCalculationRequest
     * @param corporateEntityCode
     * @param processPeriodDate
     * @return calculationRequests
     */
    @Query( "SELECT  calculationRequest "
        + "    FROM  CalculationRequest calculationRequest "
        + "   WHERE  calculationRequest.corporateEntityCode = :corporateEntityCode "
        + "     AND  calculationRequest.processPeriodDate = :processPeriodDate"
        + "     AND  calculationRequest.calculationRequestStatusCode IN "
        + CalculationServiceConstant.REVIEW_CALCULATION_QUERY_CODES
        + "     AND  calculationRequest.createRecordTimestamp = ( SELECT MAX(calculationRequest1.createRecordTimestamp) "
        + "    FROM  CalculationRequest calculationRequest1"
        + "   WHERE  calculationRequest1.calculationRunName = calculationRequest.calculationRunName "
        + "     AND  calculationRequest1.corporateEntityCode = calculationRequest.corporateEntityCode"
        + "     AND  calculationRequest1.processPeriodDate = calculationRequest.processPeriodDate)" )
    public List<CalculationRequest> findReviewCalculationRequest( @Param( "corporateEntityCode" ) String corporateEntityCode,
            @Param( "processPeriodDate" ) LocalDate processPeriodDate );

    /**
     * This method retrieves the List of CalculationRequests by CalculationRunName, CorporateEntityCode and ProcessPeriodDate
     * Method: findByReviewCalculationRequest
     * @param calculationRunName
     * @param corporateEntityCode
     * @param processPeriodDate
     * @return CalculationRequests
     */
    @Query( "SELECT  calculationRequest "
        + "    FROM  CalculationRequest calculationRequest "
        + "   WHERE  calculationRequest.calculationRunName = :calculationRunName "
        + "     AND  calculationRequest.corporateEntityCode = :corporateEntityCode "
        + "     AND  calculationRequest.processPeriodDate = :processPeriodDate" )
    public List<CalculationRequest> findByReviewCalculationRequest( @Param( "calculationRunName" ) String calculationRunName,
            @Param( "corporateEntityCode" ) String corporateEntityCode,
            @Param( "processPeriodDate" ) LocalDate processPeriodDate );

    /**
     * This method retrieves CalculationRequest by CorporateEntityCode and ProcessPeriodDate
     * Method: getClaculationRequestStatusCode
     * @param calculationRunName
     * @param corporateEntityCode
     * @param processPeriodDate
     * @return ClaculationRequest
     */
    @Query( "SELECT  calculationRequest "
        + "    FROM  CalculationRequest calculationRequest "
        + "   WHERE  calculationRequest.calculationRunName  = :calculationRunName "
        + "     AND  calculationRequest.corporateEntityCode = :corporateEntityCode "
        + "     AND  calculationRequest.processPeriodDate   = :processPeriodDate"
        + "     AND  calculationRequest.createRecordTimestamp = ( SELECT MAX(calculationRequest1.createRecordTimestamp) "
        + "    FROM  CalculationRequest calculationRequest1"
        + "   WHERE  calculationRequest1.calculationRunName = calculationRequest.calculationRunName "
        + "     AND  calculationRequest1.corporateEntityCode = calculationRequest.corporateEntityCode"
        + "     AND  calculationRequest1.processPeriodDate = calculationRequest.processPeriodDate)" )
    public CalculationRequest getClaculationRequestStatusCode( @Param( "calculationRunName" ) String calculationRunName,
            @Param( "corporateEntityCode" ) String corporateEntityCode,
            @Param( "processPeriodDate" ) LocalDate processPeriodDate );

    /**
     * This method retrieves List of CalculationRequests by CorporateEntityCode and ProcessPeriodDate
     * Method: findUnapprovedCalculationRequest
     * @param corporateEntityCode
     * @param processPeriodDate
     * @return
     */
    @Query( "SELECT  calculationRequest "
        + "    FROM  CalculationRequest calculationRequest "
        + "   WHERE  calculationRequest.corporateEntityCode = :corporateEntityCode "
        + "     AND  calculationRequest.processPeriodDate = :processPeriodDate"
        + "     AND  calculationRequest.calculationRequestStatusCode NOT IN  ('"
        + CalculationServiceConstant.CALCULATION_REQUEST_STATUS_CODE_APPROVED
        + "')"
        + "     AND  calculationRequest.createRecordTimestamp = ( SELECT MAX(calculationRequest1.createRecordTimestamp) "
        + "    FROM  CalculationRequest calculationRequest1"
        + "   WHERE  calculationRequest1.calculationRunName = calculationRequest.calculationRunName "
        + "     AND  calculationRequest1.corporateEntityCode = calculationRequest.corporateEntityCode"
        + "     AND  calculationRequest1.processPeriodDate = calculationRequest.processPeriodDate)" )
    public List<CalculationRequest> findUnapprovedCalculationRequest( @Param( "corporateEntityCode" ) String corporateEntityCode,
            @Param( "processPeriodDate" ) LocalDate processPeriodDate );

    /**
     * This method will save / update / Delete the calculation Request
     * Method: saveCalculationRequest
     * @param calculationRequest
     */
    default void saveCalculationRequest( CalculationRequest calculationRequest )
    {
        RowActionTypes rowAction = calculationRequest.getRowAction();
        switch( rowAction )
        {
            case INSERT:
            {
                LOGGER.debug( "saveCalculationRequest - INSERT : START" );
                calculationRequest.setCreateRecordTimestamp( LocalDateTime.now() );
                calculationRequest.setRequestSubmittedTimestamp( LocalDateTime.now() );
                save( calculationRequest );
                LOGGER.debug( "saveCalculationRequest - INSERT : END" );
                break;
            }
            case UPDATE:
            {
                LOGGER.debug( "saveCalculationRequest - UPDATE : START" );
                //TODO : Need to revisit for return of updateRecordTimestamp issue. Not returning the updated timestamp.
                save( calculationRequest );
                LOGGER.debug( "saveCalculationRequest - UPDATE : END" );
                break;
            }
            case DELETE:
            {
                //Cannot delete the CalculationRequest at this time
                //TODO : Future sprint exception handling
                throw new RuntimeException( " Invalid Row Action" );
            }
            case NO_ACTION:
            {
                //Do nothing - Record is not changed
                break;
            }
            default:
            {
                //TODO : Future sprint exception handling
                throw new RuntimeException( " Invalid Row Action" );
            }
        }

    }
    
    /**
     * 
     * @param calculationRequestStatusCode
     * @return
     */
	@Query( "SELECT  calculationRequest " + "    FROM  CalculationRequest calculationRequest "
			+ "   WHERE  calculationRequest.calculationRequestStatusCode = :calculationRequestStatusCode ")
	public List<CalculationRequest> findSubmittedCalculationRequest(
			@Param("calculationRequestStatusCode") String calculationRequestStatusCode);
	
	
	@Query( value = " SELECT  *  FROM  VBRCALC.CALCTN_REQ WHERE  CALCTN_REQ_STA_CD = :calculationRequestStatusCode ",
			countQuery = " SELECT  count(*)  FROM  VBRCALC.CALCTN_REQ WHERE  CALCTN_REQ_STA_CD = :calculationRequestStatusCode ",
			nativeQuery = true )
	public Page<CalculationRequest> findSubmittedCalculationRequest(
			@Param("calculationRequestStatusCode") String calculationRequestStatusCode, Pageable pageable);

}

package com.hcsc.vbr.batchdroolsdemo.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@AttributeOverrides( {
    @AttributeOverride( name = "recordEffectiveDate", column = @Column( name = "ARNGMT_RT_EFF_DT" ) ),
    @AttributeOverride( name = "recordEndDate", column = @Column( name = "ARNGMT_RT_END_DT" ) ) } )
@Table( name = "PMT_ARNGMT_RT", schema = "VBRCONF" )
public class PaymentArrangementRate extends DateRecord
{
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN" )
    @SequenceGenerator( name = "SEQ_GEN", sequenceName = "PMT_ARNGMT_RT_SQ", allocationSize = 1 )
    @Column( name = "PMT_ARNGMT_RT_ID" )
    private Integer paymentArrangementRateId;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "PMT_ARNGMT_ID" )
    private Integer paymentArrangementId;

    @NotNull
    @Column( name = "RT_NM", length = 20 )
    private String rateName;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "PMT_ARNGMT_ID", insertable = false, updatable = false )
    private PaymentArrangement paymentArrangement;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumns( {
        @JoinColumn( name = "CORP_ENT_CD", insertable = false, updatable = false ),
        @JoinColumn( name = "RT_NM", insertable = false, updatable = false ) } )
    private RateName parentRateName;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}

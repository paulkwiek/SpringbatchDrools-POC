package com.hcsc.vbr.batchdroolsdemo.dto;

import java.time.LocalDate;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StageMemberEligibilityDTO extends BaseEntityDTO {

	private static final long serialVersionUID = 1L;

	private String accountNumber;

	private String benefitAgreementNumber;

	private Integer calculationRequestId;

	private String cancelDate;

	private String capitationEntityCode;

	private String countyCode;

	private String contrId;

	private String corporateEntityCode;

	private String cityName;

	private String dataLakeCreateTimestamp;

	private String dataLakeCreateUserId;

	private String dataLakeUpdateUserId;

	private String dataLakeUpdateTimestamp;

	private String dateOfBirth;

	private String effectiveDate;

	private String firstName;

	private String fundingTypeCode;

	private String genderCode;

	private String groupNumber;

	private String hcnMbiNumber;

	private String lineOfBusinessCode;

	private String lastName;

	private Integer memberNumber;

	private String memberProviderEffectiveDate;

	private String memberProviderEndDate;

	private String memberProviderName;

	private String middleInitialName;

	private String marketingPlanId;

	private String pcpId;

	private String paymentEffectiveDate;

	private String paymentEndDate;

	private String processPeriodDate;

	private String procGFlag;

	private String productTypeCode;

	private String sectionNumber;

	private String stateCode;

	private String streetAddressLine1Text;

	private String streetAddressLine2Text;

	private String subscriberId;

	private String subscribeSequenceNumber;

	private String zipCode;

}

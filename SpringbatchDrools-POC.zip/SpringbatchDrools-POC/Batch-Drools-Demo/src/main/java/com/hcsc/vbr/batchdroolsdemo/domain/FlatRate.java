package com.hcsc.vbr.batchdroolsdemo.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "FL_RT" , schema = "VBRCONF" )
public class FlatRate extends FlatRateRecord
{
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN" )
    @SequenceGenerator( name = "SEQ_GEN", sequenceName = "FL_RT_SQ", allocationSize = 1 )
    @Column( name = "FL_RT_ID" )
    private Integer flatRateId;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumns( {
        @JoinColumn( name = "CORP_ENT_CD", insertable = false, updatable = false, referencedColumnName = "CORP_ENT_CD" ),
        @JoinColumn( name = "RT_NM", insertable = false, updatable = false, referencedColumnName = "RT_NM" ) } )
    private RateName parentRateName;

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "flatRate" )
    private List<FlatRateHistory> flatRateHistory = new ArrayList<FlatRateHistory>();

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}

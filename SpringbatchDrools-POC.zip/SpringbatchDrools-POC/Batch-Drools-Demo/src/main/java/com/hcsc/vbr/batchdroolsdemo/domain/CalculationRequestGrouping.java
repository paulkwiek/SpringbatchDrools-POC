package com.hcsc.vbr.batchdroolsdemo.domain;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.hcsc.vbr.common.domain.BaseEntity;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "CALCTN_REQ_GRPG", schema = "VBRCALC" )
public class CalculationRequestGrouping extends BaseEntity
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private CalculationRequestGroupingPK calculationRequestGroupingPK;

    @ManyToOne( fetch = FetchType.LAZY )
    @NotFound( action = NotFoundAction.IGNORE )
    @JoinColumn( name = "CALCTN_REQ_ID", insertable = false, updatable = false, referencedColumnName = "CALCTN_REQ_ID" )
    private CalculationRequest parentCalculationRequest;

    @ManyToOne( fetch = FetchType.LAZY )
    @NotFound( action = NotFoundAction.IGNORE )
    @JoinColumns( {
        @JoinColumn( name = "CALCTN_GRPG_LVL_CD", insertable = false, updatable = false, referencedColumnName = "CALCTN_GRPG_LVL_CD" ),
        @JoinColumn( name = "CALCTN_RUN_NM", insertable = false, updatable = false, referencedColumnName = "CALCTN_RUN_NM" ),
        @JoinColumn( name = "CALCTN_GRPG_LVL_VAL_TXT", insertable = false, updatable = false, referencedColumnName = "CALCTN_GRPG_LVL_VAL_TXT" ),
        @JoinColumn( name = "CORP_ENT_CD", insertable = false, updatable = false, referencedColumnName = "CORP_ENT_CD" ) } )
    private CalculationGrouping calculationGrouping;

    @Override
    public String toString()
    {
        return ReflectionToStringBuilder.toString( this,
                                                   new MultilineRecursiveToStringStyleCustom() )
                .toString();
    }
}

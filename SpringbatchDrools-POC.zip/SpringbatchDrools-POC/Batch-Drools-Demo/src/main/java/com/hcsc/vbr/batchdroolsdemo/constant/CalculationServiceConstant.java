package com.hcsc.vbr.batchdroolsdemo.constant;

public class CalculationServiceConstant
{
    public static final String CALCULATION_REQUEST_STATUS_CODE_INPROGRESS = "CRIP";
    public static final String CALCULATION_REQUEST_STATUS_CODE_COMPLETED = "CRCS";
    public static final String CALCULATION_REQUEST_STATUS_CODE_APPROVED = "CAAP";
    public static final String CALCULATION_REQUEST_APPROVED_SUBMITTED = "CASU";
    public static final String CALCULATION_SUBMITTED = "CRSU";
    public static final String STRING_TRUE = "true";
    public static final String CALCULATION_REQUEST_STATUS_CODE_APPROVAL_SUBMITTED = "CASU";
    public static final String CALCULATION_REQUEST_SUCCESSFULLY_SUBMITTED_MESSAGE =
        "Calculation Run request has been successfully submitted.";
    public static final String CALCULATION_REQUEST_NOT_SUCCESSFULLY_SUBMITTED_MESSAGE =
        "Your calculation request could not be submitted, please try again";
    public static final String PROCESSING_MONTH_STATUS_CODE_OPEN = "OPEN";
    public static final String FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_FSU = "FSU";
    public static final String FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_FIP = "FIP";
    public static final String FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_FFL = "FFL";
    public static final String FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_FAP = "FAP";
    public static final String DECIMAL_FORMAT = "##.##";
    public static final String FINANCIAL_APPROVAL_SUBMITTED = "FSU";
    public static final String CALCULATION_REQUEST_CODE_SET_NAME = "CALCREQSTATUS";
    public static final String URI_SEPARATOR = "/";
    public static final String CODE_VALUE_ITEM_CORPORATE_ENTITY_ATTRIBUTE = "corporateEntity";
    public static final String CODE_VALUE_ITEM_CODE_SET_NAME_ATTRIBUTE = "codeSetName";
    public static final String CAL_RUN_TYPE_CODE_SET_NAME = "CALCRUNTYPE";
    public static final String CALCULATION_GROUP_LOB_CODE_SET_NAME = "LOB";
    public static final String CODE_VALUE_ITEM_CODE_VALUE_TEXT_ATTRIBUTE = "codeValueText";
    public static final String FINANCIAL_REQUEST_STATUS_CD_SET_NM = "FINCREQSTATUS";
    public static final String CALCULATION_APPROVAL_SUCCESS_MESSAGE = "Approval submitted sucessfully";

    public static final String CALCULATION_REQUEST_OVERRIDDEN_STATUS = "CROR";
    public static final String FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_NOT_APPLICABLE = "N/A";
    public static final String FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_PENDING = "PENDING";

    public static final String DEFAULT_USER_ID = "I454647";
    public static final String REGEX_FORMAT = "^[A-Za-z0-9]{1}[A-Za-z0-9' -]{0,18}[A-Za-z0-9]$";

    public static final String REVIEW_CALCULATION_QUERY_CODES = "('CRCS','CASU','CAIP','CAFL','CAAP')";

    public static final String CALCULATION_RUN_INSERTED = "New Run successfully saved.";
    public static final String CALCULATION_RUN_UPDATED = "Calculation Run Updated successfully";
    public static final String CALCULATION_RUN_DELETED = "Calculation Run Deleted successfully";
    public static final String CALCULATION_RUN_FETCHED = "CalculationRunNames fetched successfully";
    public static final String CALCULATION_RUN_VALID_STATUS_CODE = "VA";
    public static final String CALCULATION_GROUPING_SELLINDICATOR = "Y";

    public static final String CALCULATION_RUN_COMPONENT = "Calculation Run";
    public static final String CALCULATION_RUN_NAME_FIELD = "calculationRunName";
    public static final String CALCULATION_GROUPING_FIELD = "calculationGroupings";
    public static final String FINANCE_REQUEST_SUCCESS_MESSAGE = "Finance request saved successfully";

    public static final String CODE_API_CLIENT_ERRORID_PARAMETER = "id";
    public static final String CALCULATION_ERROR_MESSAGE_SEPERATOR = " : ";
    public static final String PROCESSING_MONTH_COMPONENT = "Processing Month";
    public static final String PROCESSING_MONTH_FIELD = "processingMonth";
    public static final String REVIEW_CALCULATION_RUN_NAMES_SUCCESS_MESSAGE = "Review Calculation Run Names fetched successfully";
    public static final String CALCULATION_REQUESTS_SUCCESSFUL_MESSAGE = "CalculationRequest fetched successfully";

    public static final String ACCESS_DENIED_EXCEPTION_ERROR_MESSAGE_DESCRIPTION =
        "User role does not have permission to execute this function";
    public static final String DEFAULT_EXCEPTION_MESSAGE_CATEGORY_CODE = "ERR";
    public static final String DEFAULT_EXCEPTION_SEVERITY_LVL = "E";

}

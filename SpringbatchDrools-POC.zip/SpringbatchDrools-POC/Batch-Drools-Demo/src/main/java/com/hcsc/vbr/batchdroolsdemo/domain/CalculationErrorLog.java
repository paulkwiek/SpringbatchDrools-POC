package com.hcsc.vbr.batchdroolsdemo.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "CALCTN_ERR_LOG", schema = "VBRCALC" )

public class CalculationErrorLog extends BaseEntity
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "CALCTN_ERR_LOG_SQ_GENERATOR" )
    @SequenceGenerator( name = "CALCTN_ERR_LOG_SQ_GENERATOR", sequenceName = "CALCTN_ERR_LOG_SQ" )
    @Column( name = "CALCTN_ERR_LOG_ID" )
    private Integer calculationErrorLogId;

    @NotNull
    @Column( name = "ERR_MSG_ID" )
    private Integer errorMessageId;

    @NotNull
    @Column( name = "CALCTN_REQ_ID" )
    private Integer calculationRequestId;

    @Column( name = "PMT_ARNGMT_ID" )
    private Integer paymentArrangementId;

    @Column( name = "PMT_ARNGMT_NM", length = 20 )
    private String paymentArrangementName;

    @Column( name = "PMT_TYP_CD", length = 10 )
    private String paymentTypeCode;

    @Column( name = "LOB_CD", length = 10 )
    private String lobCode;

    @NotNull
    @Column( name = "JOB_NM", length = 50 )
    private String jobName;

    @Column( name = "MBR_ELIG_ID" )
    private Integer memberEligibilityId;

    @Column( name = "PAY_TO_PFIN_ID", length = 10 )
    private String payToPfinId;

    @Column( name = "ERR_MSG_CNTXT_TXT", length = 1000 )
    private String errorMessageContextText;
    
    @Column( name = "BAD_MBR_ELIG_ID", length = 10 )
    private String badMemberElgibilityId;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "CALCTN_REQ_ID", insertable = false, updatable = false, referencedColumnName = "CALCTN_REQ_ID" )
    private CalculationRequest parentCalculationRequest;
    
    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "BAD_MBR_ELIG_ID", insertable = false, updatable = false, referencedColumnName = "BAD_MBR_ELIG_ID" )
    private BadMemberElgibilty parentBadMemberEligibility;
    
    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "MBR_ELIG_ID", insertable = false, updatable = false, referencedColumnName = "MBR_ELIG_ID" )
    private MemberEligibility parentMemberEligibility;
}

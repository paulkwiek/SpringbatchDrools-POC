package com.hcsc.vbr.batchdroolsdemo.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@AttributeOverrides( { @AttributeOverride( name = "createUserId", column = @Column( name = "REC_CRTE_TS" ) ) } )
@Table( name = "FINCL_PMT", schema = "VBRCALC" )
public class FinancePayment extends BaseEntity
{

    /**
     * 
     */

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "FINCL_PMT_SQ_GENERATOR" )
    @SequenceGenerator( name = "FINCL_PMT_SQ_GENERATOR", sequenceName = "FINCL_PMT_SQ" )
    @Column( name = "FINCL_PMT_ID" )
    private Integer financePaymentId;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "PROC_PRD_DT" )
    private LocalDate processPeriodDate;

    @NotNull
    @Column( name = "VBR_PAYE_ID" )
    private Integer vbrPayeeId;

    @NotNull
    @Column( name = "PAY_TO_PFIN_ID", length = 10 )
    private String payToPfinId;

    @NotNull
    @Column( name = "PROD_TYP_CD", length = 20 )
    private String productTypeCode;

    @NotNull
    @Column( name = "PMT_EFF_DT" )
    private LocalDate paymentEffectiveDate;

    @NotNull
    @Column( name = "PMT_END_DT" )
    private LocalDate paymentEndDate;

    @NotNull
    @Column( name = "FEP_IND", length = 20 )
    private String fepIndicator;

    @NotNull
    @Column( name = "FINCL_PMT_STA_CD", length = 20 )
    private String financePaymentStatusCode;

    @NotNull
    @Column( name = "TOT_PMT_AMT", precision = 13, scale = 2 )
    private Double totalPaymentAmount;

    @NotNull
    @Column( name = "PMT_METH_CD", length = 20 )
    private String paymentMethodCode;

    @NotNull
    @Column( name = "EFT_CHK_NBR" )
    private Integer eftCheckNumber;

    @NotNull
    @Column( name = "ISS_DT" )
    private LocalDate issueDate;

    @NotNull
    @Column( name = "EFT_TRKG_ID", length = 20 )
    private String eftTrackingId;

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentFinancePayment" )
    private List<FinancePaymentFinancePaymentDetailReference> financePaymentFinancePaymentDetailReferenceList =
        new ArrayList<FinancePaymentFinancePaymentDetailReference>();
}

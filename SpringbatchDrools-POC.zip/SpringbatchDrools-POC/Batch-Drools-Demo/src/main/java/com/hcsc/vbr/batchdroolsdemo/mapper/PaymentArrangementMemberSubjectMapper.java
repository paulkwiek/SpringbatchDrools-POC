package com.hcsc.vbr.batchdroolsdemo.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.batchdroolsdemo.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.batchdroolsdemo.dto.PaymentArrangementMemberSubjectDTO;

@Mapper( componentModel = "spring" )
public interface PaymentArrangementMemberSubjectMapper
{
    PaymentArrangementMemberSubjectMapper INSTANCE = Mappers.getMapper( PaymentArrangementMemberSubjectMapper.class );

    public PaymentArrangementMemberSubjectDTO toPaymentArrangementMemberSubjectDTO( PaymentArrangementMemberSubject subject );

    public List<PaymentArrangementMemberSubjectDTO> toPaymentArrangementMemberSubjectDTOs(
            List<PaymentArrangementMemberSubject> subjects );

    public PaymentArrangementMemberSubject toPaymentArrangementMemberSubject( PaymentArrangementMemberSubjectDTO subjectDTO );

    public List<PaymentArrangementMemberSubject> toPaymentArrangementMemberSubjects(
            List<PaymentArrangementMemberSubjectDTO> subjectDTOs );

}

package com.hcsc.vbr.batchdroolsdemo.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "STAG_PROV", schema = "VBRCALC")
public class StagingProvider extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PROV_ID")
	private String providerID;

	@Column(name = "CALCTN_REQ_ID")
	private Integer calculationRequestId;

	@Column(name = "CORP_ENT_CD", length = 3)
	private String corporateEntityCode;

	@Column(name = "SRC_CD")
	private String sourceCode;

	@Column(name = "STA_RESON_CD")
	private String statusReasonCode;

	@Column(name = "EFF_DT")
	private String providerEffectiveStartDate;

	@Column(name = "END_DT")
	private String providerEndDate;

	@Column(name = "REC_STA_CD")
	private String recordStatusCode;

	@Column(name = "MEDGRP_ORG_TYP_CD")
	private String medgroupTypeCode;

	@Column(name = "PROV_CLS_CD")
	private String providerCLSCode;

	@Column(name = "NTWK_CD")
	private String networkCode;

	@Column(name = "SUBNWK_CD")
	private String subnetworkCode;

	@Column(name = "GRP_ID")
	private String groupId;

	@Column(name = "GROU_TYP_CD")
	private String groupTypeCode;

	@Column(name = "HMO_GRP_TYP_CD")
	private String hmoGroupTypeCode;

	@Column(name = "ACTVN_DT")
	private String activationDate;

	@Column(name = "AUTO_COVG_BLD")
	private String autoCoverageBLD;

	@Column(name = "PROV_LOC_ID")
	private String providerLocationId;

	@Column(name = "CDC_ACTN_CD")
	private String cdcAccountCode;

	@Column(name = "SRC_LST_CHG_TS")
	private String srcLastChangeTs;

	@Column(name = "LST_CHG_USR_ID")
	private String lastChangeUserId;

	@Column(name = "VLDT_IND")
	private String validationIndicator;

	@Column(name = "OVRRD_FST_NM")
	private String overrideFirstName;

	@Column(name = "OVRRD_LST_NM")
	private String overrideLastName;

	@Column(name = "OVRRD_MAIDN_NM")
	private String overrideMaidenName;

	@Column(name = "OVRRD_MID_NM")
	private String overrideMiddleName;

	@Column(name = "OVRRD_SUFX_NM")
	private String overrideSuffixName;

	@Column(name = "OVRRD_TTL_NM")
	private String overrideTitleName;

	@Column(name = "OVRRD_ORGZN_NM")
	private String overrideOrgName;

	@Column(name = "OVRRD_ORGZN_SCND_NM")
	private String overrideOrgSecondaryName;

	@Column(name = "PAY_TO_CD")
	private String payToCode;

	@Column(name = "FCLTY_PLN_CD")
	private String facilityPlanCode;

	@Column(name = "PROV_FINCL_TYP_CD")
	private String providerFinanceTypeCode;

	@Column(name = "RNPS_NBR")
	private String rnpsNumber;

	@Column(name = "RNPS_NBR_SEQN")
	private String rnpsNumberSequence;

	@Column(name = "BILG_PROV_FINCL_ID")
	private String billingProviderFinancialId;

	@Column(name = "PROV_LOC_TAX_STA_RSN_CD")
	private String providerLocationTaxReasonCode;

	@Column(name = "BILG_LOC_ID")
	private String billingLocationId;

	@Column(name = "PROV_FINCL_TAX_LOC_CLOS_DT")
	private String providerFinanceLocClosureDate;

	@Column(name = "PROV_FINCL_TAX_LOC_ID_NBR")
	private String providerFinanceLocIdNumber;

	@Column(name = "ISS_ID_NBR")
	private String issuerIdNumber;

	@Column(name = "PROV_ID_TYP_CD")
	private String providerIdTypeCode;

	@Column(name = "LGCY_MCARE_PRI_IND")
	private String legacyMedicarePrimaryIndicator;

	@Column(name = "PROV_FINCL_ID")
	private String providerFinanceId;

	@Column(name = "PROV_TAX_ID")
	private String providerTaxId;

	@Column(name = "LOC_USG_TYP_CD")
	private String locationUsageTypeCode;


	@Column(name = "PIN_GRP_CAPT_EFF_DT")
	private String pinGroupCAPTEffectiveDate;

	@Column(name = "PIN_GRP_CAPT_END_DT")
	private String pinGroupCAPTEndDate;

	@Column(name = "PIN_GRP_STA_EFF_DT")
	private String pinGroupStatusEffectiveDate;

	@Column(name = "PIN_GRP_STA_END_DT")
	private String pinGroupStatusEndDate;

	@Column(name = "PIN_GRP_STA_CD")
	private String pinGroupStatusCode;

	@Column(name = "PROV_FINCL_TAX_LOC_EFF_DT")
	private String providerFinaceLocationEffectiveDate;

	@Column(name = "PROV_FINCL_TAX_LOC_END_DT")
	private String providerFinaceLocationEndDate;

	@Column(name = "PROV_FINCL_TAX_STA_RSN_CD")
	private String providerFinaceStatusReasonCode;

}

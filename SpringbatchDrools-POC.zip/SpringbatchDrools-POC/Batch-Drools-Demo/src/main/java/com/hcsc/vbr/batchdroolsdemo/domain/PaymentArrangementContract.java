package com.hcsc.vbr.batchdroolsdemo.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@AttributeOverrides( {
    @AttributeOverride( name = "recordEffectiveDate", column = @Column( name = "CONTR_EFF_DT" ) ),
    @AttributeOverride( name = "recordEndDate", column = @Column( name = "CONTR_END_DT" ) ) } )
@Table( name = "PMT_ARNGMT_CONTR", schema = "VBRCONF" )
public class PaymentArrangementContract extends DateRecord
{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "PMT_ARNGMT_CONTR_SQ_GENERATOR" )
    @SequenceGenerator( name = "PMT_ARNGMT_CONTR_SQ_GENERATOR", sequenceName = "PMT_ARNGMT_CONTR_SQ", allocationSize = 1 )
    @Column( name = "PMT_ARNGMT_CONTR_ID" )
    private Integer paymentArrangementContractId;

    @Column( name = "PGM_CD", length = 20 )
    private String programCode;

    @Column( name = "CONTR_DESC", length = 100 )
    private String contractDescription;

    @Override
    public String toString()
    {
        return ReflectionToStringBuilder.toString( this,
                                                   new MultilineRecursiveToStringStyleCustom() )
                .toString();
    }

}

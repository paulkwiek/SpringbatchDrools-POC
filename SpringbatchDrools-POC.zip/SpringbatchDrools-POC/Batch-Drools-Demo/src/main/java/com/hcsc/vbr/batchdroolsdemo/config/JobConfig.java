package com.hcsc.vbr.batchdroolsdemo.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort.Direction;

import com.hcsc.vbr.batchdroolsdemo.domain.CalculationArrangements;
import com.hcsc.vbr.batchdroolsdemo.domain.CalculationMemberDetail;
import com.hcsc.vbr.batchdroolsdemo.domain.CalculationRequest;
import com.hcsc.vbr.batchdroolsdemo.repository.CalculationArrangementsRepository;
import com.hcsc.vbr.batchdroolsdemo.repository.CalculationRequestRepository;
import com.hcsc.vbr.batchdroolsdemo.service.CalculationRequestService;

@Configuration
public class JobConfig {

	@Autowired
	private ItemReader<String> itemReader;
	@Autowired
	private ItemProcessor<String, String> itemProcessor;
	@Autowired
	private ItemWriter<String> itemWriter;
	
//	@Autowired
//	private ItemProcessor<CalculationArrangements, String> calculationItemProcessor;
	
	@Autowired
	private ItemProcessor<CalculationRequest, String> calculationItemProcessor;
	
//	@Autowired
//	private ItemReader<CalculationArrangements> calculationItemReader;
	
	@Autowired
	private CalculationRequestRepository calculationRequestRepository;
	
	@Autowired
	@Qualifier("vbrEntityManagerFactory")
	private EntityManagerFactory entityManagerFactory;
	
	
	@Autowired
	private CalculationRequestService calculationRequestService;

//	@Bean
	public Job job(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory) {

		Step stepOne = stepBuilderFactory.get("Drools-Steps").<String, String>chunk(1).reader(itemReader)
				.processor(itemProcessor).writer(itemWriter).build();

		return jobBuilderFactory.get("Drools-Job").incrementer(new RunIdIncrementer()).start(stepOne).build();
	}
	
	@Bean
	public Job job2(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory) throws Exception {

		Step stepOne = stepBuilderFactory.get("Calculations-Steps").<CalculationRequest, String>chunk(1).reader(reader())
				.processor(calculationItemProcessor).writer(itemWriter).build();

		return jobBuilderFactory.get("Calculations-Job").incrementer(new RunIdIncrementer()).start(stepOne).build();
	}
	
//	@Bean
	public ItemReader<CalculationArrangements> itemReader() {
		System.out.println("inside reader");
		
		return new ListItemReader<CalculationArrangements>(
				calculationRequestService.getSubmittedCalculationArrangements());
	}
	
	@Bean
	public RepositoryItemReader<CalculationRequest> reader(){
		System.out.println("inside Repo reader");
		RepositoryItemReader<CalculationRequest> repositoryItemReader = new RepositoryItemReader<CalculationRequest>();
		repositoryItemReader.setRepository(calculationRequestRepository);
		repositoryItemReader.setMethodName("findSubmittedCalculationRequest");
		List<String> arguments = new ArrayList<String>();

		arguments.add("SUBMITTED");
		repositoryItemReader.setArguments(arguments);
		HashMap<String, Direction> sorts = new HashMap<>();
//        sorts.put("id", Direction.DESC);
		repositoryItemReader.setSort(sorts);
//      pagination size 10 by default
//		repositoryItemReader.setPageSize(5);
		return repositoryItemReader;
	}
	
//	  @Bean
	  public JpaPagingItemReader<CalculationArrangements> readerJpa() throws Exception {
		  String jpqlQuery = "select a from CalculationArrangements a"
		  		+ " WHERE  a.parentCalculationRequest.calculationRequestStatusCode = 'SUBMITTED' ";

  		JpaPagingItemReader<CalculationArrangements> reader = new JpaPagingItemReader<CalculationArrangements>();
		reader.setQueryString(jpqlQuery);
  		reader.setEntityManagerFactory(entityManagerFactory);
  		reader.setPageSize(3);
  		reader.afterPropertiesSet();
  		reader.setSaveState(true);
  		return reader;
	  }
	
	

	

}

package com.hcsc.vbr.batchdroolsdemo.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.batchdroolsdemo.domain.PaymentArrangementRate;
import com.hcsc.vbr.batchdroolsdemo.dto.PaymentArrangementRateDTO;

@Mapper( componentModel = "spring" )
public interface PaymentArrangementRateMapper
{
    PaymentArrangementRateMapper INSTANCE = Mappers.getMapper( PaymentArrangementRateMapper.class );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementRateDTO toPaymentArrangementRateDTO( PaymentArrangementRate paymentArrangementRate );

    @IterableMapping( elementTargetType = PaymentArrangementRateDTO.class, qualifiedByName = "toPaymentArrangementRateDTO" )
    public List<PaymentArrangementRateDTO> toPaymentArrangementRateDTOs( List<PaymentArrangementRate> paymentArrangementRates );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementRate toPaymentArrangementRate( PaymentArrangementRateDTO paymentArrangementRateDTO );

    @IterableMapping( elementTargetType = PaymentArrangementRate.class, qualifiedByName = "toPaymentArrangementRate" )
    public List<PaymentArrangementRate> toPaymentArrangementRates( List<PaymentArrangementRateDTO> paymentArrangementRateDTOs );
}

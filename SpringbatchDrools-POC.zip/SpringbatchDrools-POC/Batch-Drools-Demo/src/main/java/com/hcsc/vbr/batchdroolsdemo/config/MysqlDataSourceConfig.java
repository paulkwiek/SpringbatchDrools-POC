package com.hcsc.vbr.batchdroolsdemo.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories( entityManagerFactoryRef = "mySqlEntityManagerFactory", transactionManagerRef = "mySqlTransactionManager" )
@EntityScan( { "com.hcsc.vbr.batchdroolsdemo.mysql" } )
public class MysqlDataSourceConfig {

	@Primary
	@Bean(name = "mySqldataSource")
	@ConfigurationProperties(prefix = "spring.second-datasource")
	public DataSource mySqldataSource() {
		DataSource mySqlDS = DataSourceBuilder.create().build();
		return mySqlDS;
	}

	@Primary
	@Bean(name = "mySqlEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean mySqlEntityManager() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(mySqldataSource());
		em.setPackagesToScan(new String[] { "com.hcsc.vbr.batchdroolsdemo.mysql" });

		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		em.setJpaProperties(additionalJpaProperties());
		return em;
	}

	/**
	 * Method: additionalJpaProperties
	 * 
	 * @return
	 */
	private Properties additionalJpaProperties() {
		Properties properties = new Properties();
		properties.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
		properties.setProperty("hibernate.show_sql", "true");
		return properties;
	}

	/**
	 * Method: mySqlTransactionManager
	 * 
	 * @return
	 */

	@Primary
	@Bean(name = "mySqlTransactionManager")
	public PlatformTransactionManager mySqlTransactionManager() {

		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(mySqlEntityManager().getObject());
		return transactionManager;
	}

}

package com.hcsc.vbr.batchdroolsdemo.batch;

import java.util.ArrayList;
import java.util.List;

import org.springframework.aop.support.AopUtils;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.batchdroolsdemo.domain.CalculationArrangements;
import com.hcsc.vbr.batchdroolsdemo.service.CalculationRequestService;

//@Component
public class CalculationRequestItemReader implements ItemReader<CalculationArrangements> {

	@Autowired
	private CalculationRequestService calculationRequestService;

//	@Override
//	public CalculationArrangements read()
//			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	
	
	private List<CalculationArrangements> list;

	public CalculationRequestItemReader(List<CalculationArrangements> list) {
		 calculationRequestService.getSubmittedCalculationArrangements();
		if (AopUtils.isAopProxy(list)) {
			this.list = list;
		}
		else {
			this.list = new ArrayList<CalculationArrangements>(list);
		}
	}

    @Override
	public CalculationArrangements read() {
		if (!list.isEmpty()) {
			return list.remove(0);
		}
		return null;
	}


}

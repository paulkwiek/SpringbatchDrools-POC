package com.hcsc.vbr.batchdroolsdemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcsc.vbr.batchdroolsdemo.domain.StageMemberEligibility;

public interface StageMemberEligibilityRepository extends JpaRepository<StageMemberEligibility, String> {

}

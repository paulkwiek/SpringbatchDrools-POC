package com.hcsc.vbr.batchdroolsdemo.validations;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.batchdroolsdemo.dto.DateValidationDTO;
import com.hcsc.vbr.batchdroolsdemo.dto.PaymentArrangementDTO;
import com.hcsc.vbr.batchdroolsdemo.dto.VbrPayeeDTO;

@Component
public class DateValidation {

	@Autowired
	private KieSession session;

	public String validateDate(PaymentArrangementDTO paymentArrangementDTO, VbrPayeeDTO vbrPayeeDTO) {

//		pymntArrangementDTO.setRecordEffectiveDate("2020-01-01");
//		pymntArrangementDTO.setRecordEndDate("2020-12-31");
//		vbrPayeeDTO.setRecordEffectiveDate("2020-03-01");
//		vbrPayeeDTO.setRecordEndDate("2020-10-01");

		DateValidationDTO dateComparionResult;

		// Checking for Record effective start date
		dateComparionResult = executeDateRules(paymentArrangementDTO.getRecordEffectiveDate(),
				vbrPayeeDTO.getRecordEffectiveDate());
		boolean isStartDateValid = dateComparionResult.IsDateValid;
		System.out.println("isStartDateValid value is ::" + isStartDateValid);

		// Checking for Record effective end date
		dateComparionResult = executeDateRules(vbrPayeeDTO.getRecordEndDate(), paymentArrangementDTO.getRecordEndDate());
		boolean isEndDateValid = dateComparionResult.IsDateValid;
		System.out.println("isEndDateValid value is ::" + isEndDateValid);

		if (isStartDateValid && isEndDateValid) {
			System.out.println("Valid Dates");
			return "valid Dates";
		} else {
			System.out.println("Invalid Dates");
			return "Invalid Dates";
		}

	}

	public DateValidationDTO executeDateRules(String dateOne, String dateSecond) {

		DateValidationDTO dateDTO = new DateValidationDTO();

		dateDTO.setDateOne(DateValidation.convertDate(dateOne));
		dateDTO.setDateSecond(DateValidation.convertDate(dateSecond));

		System.out.println("dateDTO  isDateValid field value prior to rule fired ::: " + dateDTO.IsDateValid);

		session.insert(dateDTO);
		session.fireAllRules();
		System.out.println("dateDTO  isDateValid field value post rule is fired :::" + dateDTO.IsDateValid);
		return dateDTO;
	}

	public static Date convertDate(String date) {

		SimpleDateFormat sdformat = new SimpleDateFormat("MM/dd/yyyy");
		Date convertedDate = null;

		try {
			convertedDate = sdformat.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
			System.out.println("Error occured inside convertDate Method and error message is :" + e.getMessage());
		}

		return convertedDate;

	}
}

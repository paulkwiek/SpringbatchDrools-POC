package com.hcsc.vbr.batchdroolsdemo.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.batchdroolsdemo.domain.PaymentArrangementPayee;
import com.hcsc.vbr.batchdroolsdemo.domain.VbrPayee;
import com.hcsc.vbr.batchdroolsdemo.dto.PaymentArrangementPayeeDTO;
import com.hcsc.vbr.batchdroolsdemo.dto.VbrPayeeDTO;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;

@Mapper( componentModel = "spring" )
public interface VbrPayeeMapper
{
    VbrPayeeMapper INSTANCE = Mappers.getMapper( VbrPayeeMapper.class );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( source = "networkAssocProviderId", target = "networkAssociationID" )
    public VbrPayeeDTO toVbrPayeeDTO( VbrPayee vbrPayee );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( source = "networkAssociationID", target = "networkAssocProviderId" )
    public VbrPayee toVbrPayee( VbrPayeeDTO vbrPayeeDTO );

    // @Mapping( target = "vbrPayee", ignore = true )
    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementPayeeDTO toPaymentArrangmentPayeeDTO( PaymentArrangementPayee payementArrangementPayee );

    @Mapping( source = "corpEntityCode", target = "corporateEntityCode" )
    @Mapping( source = "pingroupID", target = "pinGroupId" )
    @Mapping( source = "pingroupName", target = "pinGroupName" )
    @Mapping( source = "taxId", target = "taxIdNumber" )
    @Mapping( source = "capitationTypeCode", target = "capitationCode" )
    @Mapping( source = "payToPFINId", target = "payToPfinId" )
    @Mapping( source = "PINGroupEffectiveDate", target = "pinGroupEffectiveDate" )
    @Mapping( source = "PINGroupEndDate", target = "pinGroupEndDate" )
    @Mapping( source = "networkAssociationID", target = "networkAssociationID", qualifiedByName = "StringToInteger" )
    @Mapping( source = "processCode", target = "capitationProcessCode" )
    public VbrPayeeDTO toVbrPayeeDTO( ProviderAPIResponseDTO providerAPIResponseDTO );

    @Mapping( source = "capitationTypeCode", target = "capitationType" )
    @Mapping( source = "payToPFINId", target = "pfin" )
    @Mapping( source = "PINGroupEffectiveDate", target = "pinGroupEffectiveDate" )
    @Mapping( source = "PINGroupEndDate", target = "pinGroupEndDate", defaultValue = "2999-12-31" )
    @Mapping( target = "pfinEndDate", defaultValue = "2999-12-31" )

    public ProviderAPISearchResponseDTO toProviderAPISearchResponseDTO( ProviderAPIResponseDTO providerApiResponseDTO );


    @Mapping( source = "corpEntityCode", target = "corporateEntityCode" )
    @Mapping( source = "pingroupID", target = "pinGroupId" )
    @Mapping( source = "pingroupName", target = "pinGroupName" )
    @Mapping( source = "taxId", target = "taxIdNumber" )
    @Mapping( source = "capitationTypeCode", target = "capitationCode" )
    @Mapping( source = "payToPFINId", target = "payToPfinId" )
    @Mapping( source = "PINGroupEffectiveDate", target = "pinGroupEffectiveDate" )
    @Mapping( source = "PINGroupEndDate", target = "pinGroupEndDate" )
    @Mapping( source = "networkAssociationID", target = "networkAssociationID", qualifiedByName = "StringToInteger" )
    public VbrPayeeDTO toVbrPayeeDTO( ProviderAPIResponseDTO providerAPIResponseDTO,
            @MappingTarget VbrPayeeDTO vbrpayeeDTO );

    @Named( value = "StringToInteger" )
    default Integer stringToInteger( String value )
    {
        return Integer.parseInt( value );

    }
}

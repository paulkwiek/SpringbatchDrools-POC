package com.hcsc.vbr.batchdroolsdemo.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FlatRateDTO extends DateRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer flatRateId;

    private String corporateEntityCode;

    private String rateName;

    private Double femaleFlatRateAmount;

    private Double maleFlatRateAmount;

    private String commentText;

    private List<FlatRateHistoryDTO> flatRateHistory = new ArrayList<FlatRateHistoryDTO>();

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}

package com.hcsc.vbr.batchdroolsdemo.dto;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.BaseEntityDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentArrangementMemberSubjectDTO extends BaseEntityDTO
{

    private static final long serialVersionUID = 1L;

    private Integer paymentArrangementMemberSubjectId;

    private String planStateCode;

    private String productTypeCode;

    private String benefitPlanStateCode;

    private String actionCode;

    private String benefitPlanNumber;

    private String lineOfBusinessCode;

    private String accountnumber;

    private String groupId;

    private String sectionNumber;

    private String copayCode;

    private String captitationEntityCode;

    private String siteId;

    private Integer benefitArrangementNumber;

    private String memberLocationId;

    private String networkRiskLevelCode;

    private Integer paymentArrangementId;

    private String corporateEntityCode;

    private String fundingTypeCode;

    private String contractId;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}

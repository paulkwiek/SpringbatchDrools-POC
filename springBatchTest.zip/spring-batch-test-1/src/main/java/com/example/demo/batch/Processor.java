package com.example.demo.batch;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.example.demo.model.VBRPayee;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.example.demo.model.VBRPayee;

@Component
public class Processor implements ItemProcessor<VBRPayee,VBRPayee> {


	    @Override
	    public VBRPayee process(VBRPayee vbrpayee) throws Exception {
	        
	        return vbrpayee;
	    }

}

package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.PaymentArrangementPayee;

public interface PaymentArrangementPayeeRepository extends JpaRepository<PaymentArrangementPayee, Integer> {

}

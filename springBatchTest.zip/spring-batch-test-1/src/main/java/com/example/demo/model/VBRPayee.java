package com.example.demo.model;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class VBRPayee {
	   @Id
	    private Integer VbrPayeId;
	    private String  CorpEntCd;
		private String PinGrpId;
		private String  PinGrpNm;
		private String CapProcCd;
		private String NtwkCd;
		private String TinNbr;
		private Date    VbrPayeEffDt;
		private Date    VbrPayeEndDt;
		private String CapCd;
		private String PayToPfinId;
		private Integer NtwkAssnProvId;
		private Date CrteTs;
		private String CrteUsrId;
		private String UpdUsrId;
		private Date UpdTs;
		private String ProvFstNm;
		private String ProvLstNm;
		private String ProvTtlCd;
		private String  ProvOrgznNm;
		private String  ProvOrgznScndNm;
		private String  AddrLn1Txt;
		private String  AddrLn2Txt;
		private String  CtyNm;
		private String StPrvncCd;
		private String PostlCd;
		private String SiteId;
		
		
		
		public VBRPayee() {
			
		}

		public VBRPayee(Integer vbrPayeId, String corpEntCd, String pinGrpId, String pinGrpNm, String capProcCd,
				String ntwkCd, String tinNbr, Date vbrPayeEffDt, Date vbrPayeEndDt, String capCd, String payToPfinId,
				Integer ntwkAssnProvId, Date crteTs, String crteUsrId, String updUsrId, Date updTs, String provFstNm,
				String provLstNm, String provTtlCd, String provOrgznNm, String provOrgznScndNm, String addrLn1Txt,
				String addrLn2Txt, String ctyNm, String stPrvncCd, String postlCd, String siteId) {
			
		VbrPayeId = vbrPayeId;
		CorpEntCd = corpEntCd;
		PinGrpId = pinGrpId;
		PinGrpNm = pinGrpNm;
		CapProcCd = capProcCd;
		NtwkCd = ntwkCd;
		TinNbr = tinNbr;
		VbrPayeEffDt = vbrPayeEffDt;
		VbrPayeEndDt = vbrPayeEndDt;
		CapCd = capCd;
		PayToPfinId = payToPfinId;
		NtwkAssnProvId = ntwkAssnProvId;
		CrteTs = crteTs;
		CrteUsrId = crteUsrId;
		UpdUsrId = updUsrId;
		UpdTs = updTs;
		ProvFstNm = provFstNm;
		ProvLstNm = provLstNm;
		ProvTtlCd = provTtlCd;
		ProvOrgznNm = provOrgznNm;
		ProvOrgznScndNm = provOrgznScndNm;
		AddrLn1Txt = addrLn1Txt;
		AddrLn2Txt = addrLn2Txt;
		CtyNm = ctyNm;
		StPrvncCd = stPrvncCd;
		PostlCd = postlCd;
		SiteId = siteId;
	}
		
	public Integer getVbrPayeId() {
		return VbrPayeId;
	}
	public void setVbrPayeId(Integer vbrPayeId) {
		VbrPayeId = vbrPayeId;
	}
	public String getCorpEntCd() {
		return CorpEntCd;
	}
	public void setCorpEntCd(String corpEntCd) {
		CorpEntCd = corpEntCd;
	}
	public String getPinGrpId() {
		return PinGrpId;
	}
	public void setPinGrpId(String pinGrpId) {
		PinGrpId = pinGrpId;	
	}
	
	public String getPinGrpNm() {
		return PinGrpNm;
	}
	public void setPinGrpNm(String pinGrpNm) {
		PinGrpNm = pinGrpNm;
	}
	public String getCapProcCd() {
		return CapProcCd;
	}
	public void setCapProcCd(String capProcCd) {
		CapProcCd = capProcCd;
	}
	public String getNtwkCd() {
		return NtwkCd;
	}
	public void setNtwkCd(String ntwkCd) {
		NtwkCd = ntwkCd;
	}
	public String getTinNbr() {
		return TinNbr;
	}
	public void setTinNbr(String tinNbr) {
		TinNbr = tinNbr;
	}
	public Date getVbrPayeEffDt() {
		return VbrPayeEffDt;
	}
	public void setVbrPayeEffDt(Date vbrPayeEffDt) {
		VbrPayeEffDt = vbrPayeEffDt;
	}
	public Date getVbrPayeEndDt() {
		return VbrPayeEndDt;
	}
	public void setVbrPayeEndDt(Date vbrPayeEndDt) {
		VbrPayeEndDt = vbrPayeEndDt;
	}
	public String getCapCd() {
		return CapCd;
	}
	public void setCapCd(String capCd) {
		CapCd = capCd;
	}
	public String getPayToPfinId() {
		return PayToPfinId;
	}
	public void setPayToPfinId(String payToPfinId) {
		PayToPfinId = payToPfinId;
	}
	public Integer getNtwkAssnProvId() {
		return NtwkAssnProvId;
	}
	public void setNtwkAssnProvId(Integer ntwkAssnProvId) {
		NtwkAssnProvId = ntwkAssnProvId;
	}
	public Date getCrteTs() {
		return CrteTs;
	}
	public void setCrteTs(Date crteTs) {
		CrteTs = crteTs;
	}
	public String getCrteUsrId() {
		return CrteUsrId;
	}
	public void setCrteUsrId(String crteUsrId) {
		CrteUsrId = crteUsrId;
	}
	public String getUpdUsrId() {
		return UpdUsrId;
	}
	public void setUpdUsrId(String updUsrId) {
		UpdUsrId = updUsrId;
	}
	public Date getUpdTs() {
		return UpdTs;
	}
	public void setUpdTs(Date updTs) {
		UpdTs = updTs;
	}
	public String getProvFstNm() {
		return ProvFstNm;
	}
	public void setProvFstNm(String provFstNm) {
		ProvFstNm = provFstNm;
	}
	public String getProvLstNm() {
		return ProvLstNm;
	}
	public void setProvLstNm(String provLstNm) {
		ProvLstNm = provLstNm;
	}
	public String getProvTtlCd() {
		return ProvTtlCd;
	}
	public void setProvTtlCd(String provTtlCd) {
		ProvTtlCd = provTtlCd;
	}
	public String getProvOrgznNm() {
		return ProvOrgznNm;
	}
	public void setProvOrgznNm(String provOrgznNm) {
		ProvOrgznNm = provOrgznNm;
	}
	public String getProvOrgznScndNm() {
		return ProvOrgznScndNm;
	}
	public void setProvOrgznScndNm(String provOrgznScndNm) {
		ProvOrgznScndNm = provOrgznScndNm;
	}
	public String getAddrLn1Txt() {
		return AddrLn1Txt;
	}
	public void setAddrLn1Txt(String addrLn1Txt) {
		AddrLn1Txt = addrLn1Txt;
	}
	public String getAddrLn2Txt() {
		return AddrLn2Txt;
	}
	public void setAddrLn2Txt(String addrLn2Txt) {
		AddrLn2Txt = addrLn2Txt;
	}
	public String getCtyNm() {
		return CtyNm;
	}
	public void setCtyNm(String ctyNm) {
		CtyNm = ctyNm;
	}
	public String getStPrvncCd() {
		return StPrvncCd;
	}
	public void setStPrvncCd(String stPrvncCd) {
		StPrvncCd = stPrvncCd;
	}
	public String getPostlCd() {
		return PostlCd;
	}
	public void setPostlCd(String postlCd) {
		PostlCd = postlCd;
	}
	public String getSiteId() {
		return SiteId;
	}
	public void setSiteId(String siteId) {
		SiteId = siteId;
	}
	
	public String toString() {
		return "VBRPayee [CorpEntCd=" + CorpEntCd + ", PinGrpId=" + PinGrpId + ", PinGrpNm=" + PinGrpNm + ", CapProcCd="
				+ CapProcCd + ", NtwkCd=" + NtwkCd + ", TinNbr=" + TinNbr + ", VbrPayeEffDt=" + VbrPayeEffDt
				+ ", VbrPayeEndDt=" + VbrPayeEndDt + ", CapCd=" + CapCd + ", PayToPfinId=" + PayToPfinId
				+ ", NtwkAssnProvId=" + NtwkAssnProvId + ", CrteTs=" + CrteTs + ", CrteUsrId=" + CrteUsrId
				+ ", UpdUsrId=" + UpdUsrId + ", UpdTs=" + UpdTs + ", ProvFstNm=" + ProvFstNm + ", ProvLstNm="
				+ ProvLstNm + ", ProvTtlCd=" + ProvTtlCd + ", ProvOrgznNm=" + ProvOrgznNm + ", ProvOrgznScndNm="
				+ ProvOrgznScndNm + ", AddrLn1Txt=" + AddrLn1Txt + ", AddrLn2Txt=" + AddrLn2Txt + ", CtyNm=" + CtyNm
				+ ", StPrvncCd=" + StPrvncCd + ", PostlCd=" + PostlCd + ", SiteId=" + SiteId + ", VbrPayeId="
				+ VbrPayeId + "]";
	}

}

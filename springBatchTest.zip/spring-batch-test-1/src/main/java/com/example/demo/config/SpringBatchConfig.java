package com.example.demo.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import com.example.demo.batch.Processor;
import com.example.demo.model.PaymentArrangement;
import com.example.demo.model.PaymentArrangementPayee;
import com.example.demo.model.VBRPayee;

@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {
	
	@Autowired
	private ItemProcessor<VBRPayee, VBRPayee> itemProcessor;
	
	@Autowired
	private ItemProcessor<PaymentArrangement,PaymentArrangement>  itemProcessorPaymentArrangement;
	
	@Autowired
	private ItemProcessor<PaymentArrangementPayee,PaymentArrangementPayee>  itemProcessorPaymentArrangementPayee;
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private  ItemReader<VBRPayee> itemReader;
	
	@Autowired
	private  ItemReader<PaymentArrangement> itemReaderPaymentArrangement;
	
	@Autowired
	private  ItemReader<PaymentArrangementPayee> itemReaderPaymentArrangementPayee;
	
	@Autowired
	ItemWriter<VBRPayee> itemWriter;
	
	@Autowired
	ItemWriter<PaymentArrangement> itemWriterPaymentArrangement;
	
	@Autowired
	ItemWriter<PaymentArrangementPayee> itemWriterPaymentArrangementPayee;
	
	
	
    @Bean 
	 public Step step1() { 
    	return stepBuilderFactory.get("ETL-file-load")
	                .<VBRPayee, VBRPayee>chunk(100)
	                .reader(itemReader)
	                .processor(itemProcessor)
	                .writer(itemWriter)
	                .build();
    }
    
    @Bean 
	public Step step2() { 
   	return stepBuilderFactory.get("ETL-file-load2")
	                .<PaymentArrangement, PaymentArrangement>chunk(100)
	                .reader(itemReaderPaymentArrangement)
	                .processor(itemProcessorPaymentArrangement)
	                .writer(itemWriterPaymentArrangement)
	                .build();
   } 
	        
    @Bean 
	public Step step3() { 
   	return stepBuilderFactory.get("ETL-file-load3")
	                .<PaymentArrangementPayee, PaymentArrangementPayee>chunk(100)
	                .reader(itemReaderPaymentArrangementPayee)
	                .processor(itemProcessorPaymentArrangementPayee)
	                .writer(itemWriterPaymentArrangementPayee)
	                .build();
   } 
   @Bean 
   public Job job() {

	        return jobBuilderFactory.get("ETL-Load")
	                .incrementer(new RunIdIncrementer())
	                .flow(step1())
	                .next(step2())
	                .next(step3())
	                .end()
	                .build();
   }
	 
	 	
   @Bean
	    public FlatFileItemReader<PaymentArrangement> itemReaderPaymentArrangement() {
	        FlatFileItemReader<PaymentArrangement> flatFileItemReaderPaymentArrangement = new FlatFileItemReader<>();
	        flatFileItemReaderPaymentArrangement.setResource(new FileSystemResource("src/main/resources/pmt_arngmt.csv"));
	        flatFileItemReaderPaymentArrangement.setName("CSV-ReaderPaymentArrangement");
	        flatFileItemReaderPaymentArrangement.setLinesToSkip(1);
	        flatFileItemReaderPaymentArrangement.setLineMapper(lineMapperPaymentArrangement());
	        return flatFileItemReaderPaymentArrangement;
   }
	
   @Bean
   public FlatFileItemReader<PaymentArrangementPayee> itemReaderPaymentArrangementPayee() {
       FlatFileItemReader<PaymentArrangementPayee> flatFileItemReaderPaymentArrangementPayee = new FlatFileItemReader<>();
       flatFileItemReaderPaymentArrangementPayee.setResource(new FileSystemResource("src/main/resources/pmt_arngmt_paye.csv"));
       flatFileItemReaderPaymentArrangementPayee.setName("CSV-ReaderPaymentArrangement");
       flatFileItemReaderPaymentArrangementPayee.setLinesToSkip(1);
       flatFileItemReaderPaymentArrangementPayee.setLineMapper(lineMapperPaymentArrangementPayee());
       return flatFileItemReaderPaymentArrangementPayee;
}
   
   @Bean
   public FlatFileItemReader<VBRPayee> itemReader() {
       FlatFileItemReader<VBRPayee> flatFileItemReader = new FlatFileItemReader<>();
       flatFileItemReader.setResource(new FileSystemResource("src/main/resources/vbr_payee.csv"));
       flatFileItemReader.setName("CSV-Reader");
       flatFileItemReader.setLinesToSkip(1);
       flatFileItemReader.setLineMapper(lineMapper());
       return flatFileItemReader;
   }
   
   
  
	
	@Bean
	    public LineMapper<VBRPayee> lineMapper() {
		DefaultLineMapper<VBRPayee> defaultLineMapper = new DefaultLineMapper<>();
        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
        lineTokenizer.setDelimiter(",");
        lineTokenizer.setStrict(false);
        lineTokenizer.setNames(new String[] { "VbrPayeId","CorpEntCd","PinGrpId","PinGrpNm","CapProcCd", "NtwkCd","TinNbr",	"VbrPayeEffDt",	"VbrPayeEndDt",	"CapCd","PayToPfinId","NtwkAssnProvId","CrteTs","CrteUsrId","UpdUsrId","UpdTs","ProvFstNm","ProvLstNm","ProvTtlCd","ProvOrgznNm","ProvOrgznScndNm","AddrLn1Txt","AddrLn2Txt","CtyNm","StPrvncCd","PostlCd","SiteId"});
        BeanWrapperFieldSetMapper<VBRPayee> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
    
        fieldSetMapper.setTargetType(VBRPayee.class);

        defaultLineMapper.setLineTokenizer(lineTokenizer);
        defaultLineMapper.setFieldSetMapper(fieldSetMapper);

        return defaultLineMapper;
    }
	
	@Bean
	    public LineMapper<PaymentArrangement> lineMapperPaymentArrangement() {
		DefaultLineMapper<PaymentArrangement> defaultLineMapper = new DefaultLineMapper<>();
	    DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
	    lineTokenizer.setDelimiter(",");
	    lineTokenizer.setStrict(false);
	    lineTokenizer.setNames(new String[] {"pmtArngmtId","pmtArngmtNm","corpEntCd","pmtArngmtContrId","pmtTypCd","arngmtFreqcCd","pmtArngmtTypCd","pmtArngmtEffDt","pmtArnGmtEndDt","pmtArngmtDesc","vldnStaCd","crteTs","crteUsrId","updUsrId","updTs"});
	    BeanWrapperFieldSetMapper<PaymentArrangement> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
	
	    fieldSetMapper.setTargetType(PaymentArrangement.class);
	
	    defaultLineMapper.setLineTokenizer(lineTokenizer);
	    defaultLineMapper.setFieldSetMapper(fieldSetMapper);
	
	    return defaultLineMapper;
}
	
	@Bean
    public LineMapper<PaymentArrangementPayee> lineMapperPaymentArrangementPayee() {
	DefaultLineMapper<PaymentArrangementPayee> defaultLineMapper = new DefaultLineMapper<>();
    DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
    lineTokenizer.setDelimiter(",");
    lineTokenizer.setStrict(false);
    lineTokenizer.setNames(new String[] {"pmtArngmtPayeId","pmtArngmtId","vbrPayeId","arngmtPayeEfDt","arngmtPayeEndDt","crteTs","crteUsrId","updUsrID","updTs"});
    BeanWrapperFieldSetMapper<PaymentArrangementPayee> fieldSetMapper = new BeanWrapperFieldSetMapper<>();

    fieldSetMapper.setTargetType(PaymentArrangementPayee.class);

    defaultLineMapper.setLineTokenizer(lineTokenizer);
    defaultLineMapper.setFieldSetMapper(fieldSetMapper);

    return defaultLineMapper;
}

}

package com.example.demo.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.model.PaymentArrangement;
import com.example.demo.model.VBRPayee;
import com.example.demo.repository.PaymentArrangementRepository;
import com.example.demo.repository.VBRPayeeRepository;

@Component
public class DBWriter2 implements ItemWriter<PaymentArrangement> {

    @Autowired
    private PaymentArrangementRepository vbrPayeeRepository;

	@Override
	public void write(List<? extends PaymentArrangement> arg0) throws Exception {
		vbrPayeeRepository.saveAll(arg0);	
	}
}

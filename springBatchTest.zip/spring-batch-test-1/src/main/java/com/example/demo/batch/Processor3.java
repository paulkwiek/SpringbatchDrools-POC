package com.example.demo.batch;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.example.demo.model.PaymentArrangement;
import com.example.demo.model.PaymentArrangementPayee;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;



@Component
public class Processor3 implements ItemProcessor<PaymentArrangementPayee,PaymentArrangementPayee> {


	    @Override
	    public PaymentArrangementPayee process(PaymentArrangementPayee paymentArrangementPayee) throws Exception {
	        
	        return paymentArrangementPayee;
	    }

}

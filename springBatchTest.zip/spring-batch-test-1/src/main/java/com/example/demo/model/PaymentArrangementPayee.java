package com.example.demo.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PaymentArrangementPayee {
	
	@Id
	private Integer pmtArngmtPayeId;
	private Integer pmtArngmtId;
	private Integer vbrPayeId;
	private Date arngmtPayeEfDt;
	private Date arngmtPayeEndDt;
	private Date crteTs;
	private String crteUsrId;
	private String updUsrId;
	private Date updTs;
	
	public PaymentArrangementPayee() {
	}

	public PaymentArrangementPayee(Integer pmtArngmtPayeId, Integer pmtArngmtId, Integer vbrPayeId, Date arngmtPayeEfDt,
			Date arngmtPayeEndDt, Date crteTs, String crteUsrId, String updUsrId, Date updTs) {
		this.pmtArngmtPayeId = pmtArngmtPayeId;
		this.pmtArngmtId = pmtArngmtId;
		this.vbrPayeId = vbrPayeId;
		this.arngmtPayeEfDt = arngmtPayeEfDt;
		this.arngmtPayeEndDt = arngmtPayeEndDt;
		this.crteTs = crteTs;
		this.crteUsrId = crteUsrId;
		this.updUsrId = updUsrId;
		this.updTs = updTs;
	}
	
	public Integer getPmtArngmtPayeId() {
		return pmtArngmtPayeId;
	}

	public void setPmtArngmtPayeId(Integer pmtArngmtPayeId) {
		this.pmtArngmtPayeId = pmtArngmtPayeId;
	}

	public Integer getPmtArngmtId() {
		return pmtArngmtId;
	}

	public void setPmtArngmtId(Integer pmtArngmtId) {
		this.pmtArngmtId = pmtArngmtId;
	}

	public Integer getVbrPayeId() {
		return vbrPayeId;
	}

	public void setVbrPayeId(Integer vbrPayeId) {
		this.vbrPayeId = vbrPayeId;
	}

	public Date getArngmtPayeEfDt() {
		return arngmtPayeEfDt;
	}

	public void setArngmtPayeEfDt(Date arngmtPayeEfDt) {
		this.arngmtPayeEfDt = arngmtPayeEfDt;
	}

	public Date getArngmtPayeEndDt() {
		return arngmtPayeEndDt;
	}

	public void setArngmtPayeEndDt(Date arngmtPayeEndDt) {
		this.arngmtPayeEndDt = arngmtPayeEndDt;
	}

	public Date getCrteTs() {
		return crteTs;
	}

	public void setCrteTs(Date crteTs) {
		this.crteTs = crteTs;
	}

	public String getCrteUsrId() {
		return crteUsrId;
	}

	public void setCrteUsrId(String crteUsrId) {
		this.crteUsrId = crteUsrId;
	}

	public String getUpdUsrId() {
		return updUsrId;
	}

	public void setUpdUsrId(String updUsrId) {
		this.updUsrId = updUsrId;
	}

	public Date getUpdTs() {
		return updTs;
	}

	public void setUpdTs(Date updTs) {
		this.updTs = updTs;
	}

	@Override
	public String toString() {
		return "PaymentArrangementPayee [pmtArngmtPayeId=" + pmtArngmtPayeId + ", pmtArngmtId=" + pmtArngmtId
				+ ", vbrPayeId=" + vbrPayeId + ", arngmtPayeEfDt=" + arngmtPayeEfDt + ", arngmtPayeEndDt="
				+ arngmtPayeEndDt + ", crteTs=" + crteTs + ", crteUsrId=" + crteUsrId + ", updUsrId=" + updUsrId
				+ ", updTs=" + updTs + "]";
	}

}

package com.example.demo.model;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PaymentArrangement {
	 @Id
	 private String pmtArngmtNm;
	private String corpEntCd;
	 private Integer pmtArngmtContrId;
	 private String pmtTypCd;
	 private String arngmtFreqcCd ;
	 private String pmtArngmtTypCd ;
	 private Date pmtArngmtEffDt;
	 private Date pmtArnGmtEndDt;
	 private String pmtArngmtDesc;
	 private String vldnStaCd;
	 private Date crteTs;
	 private String crteUsrId;
	 private String updUsrId;
	 private Date updTs;
	 private Integer pmtArngmtId;
	 
	 public PaymentArrangement() {
		 
	 };
	 
	 public PaymentArrangement(String pmtArngmtNm, String corpEntCd, Integer pmtArngmtContrId, String pmtTypCd,
				String arngmtFreqcCd, String pmtArngmtTypCd, Date pmtArngmtEffDt, Date pmtArnGmtEndDt, String pmtArngmtDesc,
				String vldnStaCd, Date crteTs, String crteUsrId, String updUsrId, Date updTs,
				Integer pmtArngmtId) {
		
			this.pmtArngmtNm = pmtArngmtNm;
			this.corpEntCd = corpEntCd;
			this.pmtArngmtContrId = pmtArngmtContrId;
			this.pmtTypCd = pmtTypCd;
			this.arngmtFreqcCd = arngmtFreqcCd;
			this.pmtArngmtTypCd = pmtArngmtTypCd;
			this.pmtArngmtEffDt = pmtArngmtEffDt;
			this.pmtArnGmtEndDt = pmtArnGmtEndDt;
			this.pmtArngmtDesc = pmtArngmtDesc;
			this.vldnStaCd = vldnStaCd;
			this.crteTs = crteTs;
			this.crteUsrId = crteUsrId;
			this.updUsrId = updUsrId;
			this.updTs = updTs;
			this.pmtArngmtId = pmtArngmtId;
		}
	public Integer getPmtArngmtId() {
		return pmtArngmtId;
	}
	public void setPmtArngmtId(Integer pmtArngmtId) {
		this.pmtArngmtId = pmtArngmtId;
	}
	public String getPmtArngmtNm() {
		return pmtArngmtNm;
	}
	public void setPmtArngmtNm(String pmtArngmtNm) {
		this.pmtArngmtNm = pmtArngmtNm;
	}
	public String getCorpEntCd() {
		return corpEntCd;
	}
	public void setCorpEntCd(String corpEntCd) {
		this.corpEntCd = corpEntCd;
	}
	public Integer getPmtArngmtContrId() {
		return pmtArngmtContrId;
	}
	public void setPmtArngmtContrId(Integer pmtArngmtContrId) {
		this.pmtArngmtContrId = pmtArngmtContrId;
	}
	public String getPmtTypCd() {
		return pmtTypCd;
	}
	public void setPmtTypCd(String pmtTypCd) {
		this.pmtTypCd = pmtTypCd;
	}
	public String getArngmtFreqcCd() {
		return arngmtFreqcCd;
	}
	public void setArngmtFreqcCd(String arngmtFreqcCd) {
		this.arngmtFreqcCd = arngmtFreqcCd;
	}
	public String getPmtArngmtTypCd() {
		return pmtArngmtTypCd;
	}
	public void setPmtArngmtTypCd(String pmtArngmtTypCd) {
		this.pmtArngmtTypCd = pmtArngmtTypCd;
	}
	public Date getPmtArngmtEffDt() {
		return pmtArngmtEffDt;
	}
	public void setPmtArngmtEffDt(Date pmtArngmtEffDt) {
		this.pmtArngmtEffDt = pmtArngmtEffDt;
	}
	public Date getPmtArnGmtEndDt() {
		return pmtArnGmtEndDt;
	}
	public void setPmtArnGmtEndDt(Date pmtArnGmtEndDt) {
		this.pmtArnGmtEndDt = pmtArnGmtEndDt;
	}
	public String getPmtArngmtDesc() {
		return pmtArngmtDesc;
	}
	public void setPmtArngmtDesc(String pmtArngmtDesc) {
		this.pmtArngmtDesc = pmtArngmtDesc;
	}
	public String getVldnStaCd() {
		return vldnStaCd;
	}
	public void setVldnStaCd(String vldnStaCd) {
		this.vldnStaCd = vldnStaCd;
	}
	public Date getCrteTs() {
		return crteTs;
	}
	public void setCrteTs(Date crteTs) {
		this.crteTs = crteTs;
	}
	public String getCrteUsrId() {
		return crteUsrId;
	}
	public void setCrteUsrId(String crteUsrId) {
		this.crteUsrId = crteUsrId;
	}
	public String getUpdUsrId() {
		return updUsrId;
	}
	public void setUpdUsrId(String updUsrId) {
		this.updUsrId = updUsrId;
	}
	public Date getUpdTs() {
		return updTs;
	}
	public void setUpdTs(Date updTs) {
		this.updTs = updTs;
	}
	@Override
	public String toString() {
		return "PaymentArrangement [pmtArngmtNm=" + pmtArngmtNm + ", corpEntCd=" + corpEntCd + ", pmtArngmtContrId="
				+ pmtArngmtContrId + ", pmtTypCd=" + pmtTypCd + ", arngmtFreqcCd=" + arngmtFreqcCd + ", pmtArngmtTypCd="
				+ pmtArngmtTypCd + ", pmtArngmtEffDt=" + pmtArngmtEffDt + ", pmtArnGmtEndDt=" + pmtArnGmtEndDt
				+ ", pmtArngmtDesc=" + pmtArngmtDesc + ", vldnStaCd=" + vldnStaCd + ", crteTs=" + crteTs
				+ ", crteUsrId=" + crteUsrId + ", updUsrId=" + updUsrId + ", updTs=" + updTs + ", pmtArngmtId="
				+ pmtArngmtId + "]";
	}
	
	
}

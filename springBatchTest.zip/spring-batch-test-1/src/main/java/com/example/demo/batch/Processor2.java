package com.example.demo.batch;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.example.demo.model.PaymentArrangement;


import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;



@Component
public class Processor2 implements ItemProcessor<PaymentArrangement,PaymentArrangement> {


	    @Override
	    public PaymentArrangement process(PaymentArrangement paymentArrangement) throws Exception {
	        
	        return paymentArrangement;
	    }

}

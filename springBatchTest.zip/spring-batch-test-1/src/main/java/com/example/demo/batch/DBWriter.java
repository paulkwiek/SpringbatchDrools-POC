package com.example.demo.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.model.VBRPayee;
import com.example.demo.repository.VBRPayeeRepository;

@Component
public class DBWriter implements ItemWriter<VBRPayee> {

    @Autowired
    private VBRPayeeRepository vbrPayeeRepository;

	@Override
	public void write(List<? extends VBRPayee> arg0) throws Exception {
		vbrPayeeRepository.saveAll(arg0);	
	}
}
